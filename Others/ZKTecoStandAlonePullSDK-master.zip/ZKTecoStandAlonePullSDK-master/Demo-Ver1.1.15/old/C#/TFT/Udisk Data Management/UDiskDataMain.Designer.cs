﻿namespace UdiskData
{
    partial class UDiskDataMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSSR_UserWrite = new System.Windows.Forms.Button();
            this.btnSSR_UserRead = new System.Windows.Forms.Button();
            this.lvSSRUser = new System.Windows.Forms.ListView();
            this.columnHeader9 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader10 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader11 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader12 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader13 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader14 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader15 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader16 = new System.Windows.Forms.ColumnHeader();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.lvSSRAttLog = new System.Windows.Forms.ListView();
            this.columnHeader22 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader23 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader24 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader31 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader32 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader33 = new System.Windows.Forms.ColumnHeader();
            this.btnSSRAttLogWrite = new System.Windows.Forms.Button();
            this.btnSSRAttLogRead = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label5 = new System.Windows.Forms.Label();
            this.btnTmpWrite = new System.Windows.Forms.Button();
            this.btnTmpRead = new System.Windows.Forms.Button();
            this.lvTmp = new System.Windows.Forms.ListView();
            this.columnHeader17 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader18 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader19 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader20 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader21 = new System.Windows.Forms.ColumnHeader();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.label6 = new System.Windows.Forms.Label();
            this.lvTmp10 = new System.Windows.Forms.ListView();
            this.columnHeader42 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader43 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader44 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader45 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader46 = new System.Windows.Forms.ColumnHeader();
            this.btnTmp10Write = new System.Windows.Forms.Button();
            this.btnTmp10Read = new System.Windows.Forms.Button();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.label9 = new System.Windows.Forms.Label();
            this.btnSSRSMSWrite = new System.Windows.Forms.Button();
            this.btnSSRSMSRead = new System.Windows.Forms.Button();
            this.lvSSRSMS = new System.Windows.Forms.ListView();
            this.columnHeader55 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader56 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader57 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader58 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader59 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader60 = new System.Windows.Forms.ColumnHeader();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.label10 = new System.Windows.Forms.Label();
            this.btnUDataWrite = new System.Windows.Forms.Button();
            this.btnUDataRead = new System.Windows.Forms.Button();
            this.lvUData = new System.Windows.Forms.ListView();
            this.columnHeader53 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader54 = new System.Windows.Forms.ColumnHeader();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tabControl1);
            this.groupBox1.ForeColor = System.Drawing.Color.MidnightBlue;
            this.groupBox1.Location = new System.Drawing.Point(12, 34);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(713, 425);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Udisk Data";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Location = new System.Drawing.Point(12, 21);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(688, 395);
            this.tabControl1.TabIndex = 4;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.btnSSR_UserWrite);
            this.tabPage1.Controls.Add(this.btnSSR_UserRead);
            this.tabPage1.Controls.Add(this.lvSSRUser);
            this.tabPage1.Location = new System.Drawing.Point(4, 21);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(680, 370);
            this.tabPage1.TabIndex = 1;
            this.tabPage1.Text = "SSR_User(TFT)";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(194, 302);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(293, 12);
            this.label2.TabIndex = 13;
            this.label2.Text = "It is for user information management(user.dat).";
            // 
            // btnSSR_UserWrite
            // 
            this.btnSSR_UserWrite.Location = new System.Drawing.Point(351, 329);
            this.btnSSR_UserWrite.Name = "btnSSR_UserWrite";
            this.btnSSR_UserWrite.Size = new System.Drawing.Size(106, 23);
            this.btnSSR_UserWrite.TabIndex = 12;
            this.btnSSR_UserWrite.Text = "WriteDataToFile";
            this.btnSSR_UserWrite.UseVisualStyleBackColor = true;
            this.btnSSR_UserWrite.Click += new System.EventHandler(this.btnSSR_UserWrite_Click);
            // 
            // btnSSR_UserRead
            // 
            this.btnSSR_UserRead.Location = new System.Drawing.Point(215, 329);
            this.btnSSR_UserRead.Name = "btnSSR_UserRead";
            this.btnSSR_UserRead.Size = new System.Drawing.Size(88, 23);
            this.btnSSR_UserRead.TabIndex = 11;
            this.btnSSR_UserRead.Text = "ReadDataToPC";
            this.btnSSR_UserRead.UseVisualStyleBackColor = true;
            this.btnSSR_UserRead.Click += new System.EventHandler(this.btnSSR_UserRead_Click);
            // 
            // lvSSRUser
            // 
            this.lvSSRUser.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader11,
            this.columnHeader12,
            this.columnHeader13,
            this.columnHeader14,
            this.columnHeader15,
            this.columnHeader16});
            this.lvSSRUser.GridLines = true;
            this.lvSSRUser.Location = new System.Drawing.Point(6, 6);
            this.lvSSRUser.Name = "lvSSRUser";
            this.lvSSRUser.Size = new System.Drawing.Size(669, 280);
            this.lvSSRUser.TabIndex = 1;
            this.lvSSRUser.UseCompatibleStateImageBehavior = false;
            this.lvSSRUser.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "PIN2";
            this.columnHeader9.Width = 53;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Name";
            this.columnHeader10.Width = 47;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Card";
            this.columnHeader11.Width = 55;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "Privilege";
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "Password";
            this.columnHeader13.Width = 77;
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "Group";
            this.columnHeader14.Width = 69;
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "TimeZones";
            this.columnHeader15.Width = 74;
            // 
            // columnHeader16
            // 
            this.columnHeader16.Text = "PIN";
            this.columnHeader16.Width = 68;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.lvSSRAttLog);
            this.tabPage2.Controls.Add(this.btnSSRAttLogWrite);
            this.tabPage2.Controls.Add(this.btnSSRAttLogRead);
            this.tabPage2.Location = new System.Drawing.Point(4, 21);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(680, 370);
            this.tabPage2.TabIndex = 4;
            this.tabPage2.Text = "AttLogs(TFT)";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(227, 302);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(227, 12);
            this.label4.TabIndex = 26;
            this.label4.Text = "It is for attendance logs management.";
            // 
            // lvSSRAttLog
            // 
            this.lvSSRAttLog.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader22,
            this.columnHeader23,
            this.columnHeader24,
            this.columnHeader31,
            this.columnHeader32,
            this.columnHeader33});
            this.lvSSRAttLog.GridLines = true;
            this.lvSSRAttLog.Location = new System.Drawing.Point(6, 6);
            this.lvSSRAttLog.Name = "lvSSRAttLog";
            this.lvSSRAttLog.Size = new System.Drawing.Size(669, 280);
            this.lvSSRAttLog.TabIndex = 24;
            this.lvSSRAttLog.UseCompatibleStateImageBehavior = false;
            this.lvSSRAttLog.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader22
            // 
            this.columnHeader22.Text = "PIN";
            this.columnHeader22.Width = 129;
            // 
            // columnHeader23
            // 
            this.columnHeader23.Text = "Time";
            this.columnHeader23.Width = 182;
            // 
            // columnHeader24
            // 
            this.columnHeader24.Text = "DeviceID";
            this.columnHeader24.Width = 68;
            // 
            // columnHeader31
            // 
            this.columnHeader31.Text = "Status";
            this.columnHeader31.Width = 54;
            // 
            // columnHeader32
            // 
            this.columnHeader32.Text = "Verified";
            this.columnHeader32.Width = 65;
            // 
            // columnHeader33
            // 
            this.columnHeader33.Text = "Workcode";
            this.columnHeader33.Width = 69;
            // 
            // btnSSRAttLogWrite
            // 
            this.btnSSRAttLogWrite.Location = new System.Drawing.Point(351, 329);
            this.btnSSRAttLogWrite.Name = "btnSSRAttLogWrite";
            this.btnSSRAttLogWrite.Size = new System.Drawing.Size(106, 23);
            this.btnSSRAttLogWrite.TabIndex = 22;
            this.btnSSRAttLogWrite.Text = "WriteDataToFile";
            this.btnSSRAttLogWrite.UseVisualStyleBackColor = true;
            this.btnSSRAttLogWrite.Click += new System.EventHandler(this.btnSSRAttLogWrite_Click);
            // 
            // btnSSRAttLogRead
            // 
            this.btnSSRAttLogRead.Location = new System.Drawing.Point(215, 329);
            this.btnSSRAttLogRead.Name = "btnSSRAttLogRead";
            this.btnSSRAttLogRead.Size = new System.Drawing.Size(88, 23);
            this.btnSSRAttLogRead.TabIndex = 21;
            this.btnSSRAttLogRead.Text = "ReadDataToPC";
            this.btnSSRAttLogRead.UseVisualStyleBackColor = true;
            this.btnSSRAttLogRead.Click += new System.EventHandler(this.btnSSRAttLogRead_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label5);
            this.tabPage3.Controls.Add(this.btnTmpWrite);
            this.tabPage3.Controls.Add(this.btnTmpRead);
            this.tabPage3.Controls.Add(this.lvTmp);
            this.tabPage3.Location = new System.Drawing.Point(4, 21);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(680, 370);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Tmp9.0";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(98, 302);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(491, 12);
            this.label5.TabIndex = 27;
            this.label5.Text = "It is for fingerprint templates management.(For devices with 9.0 arithmetic only)" +
                "";
            // 
            // btnTmpWrite
            // 
            this.btnTmpWrite.Location = new System.Drawing.Point(351, 329);
            this.btnTmpWrite.Name = "btnTmpWrite";
            this.btnTmpWrite.Size = new System.Drawing.Size(106, 23);
            this.btnTmpWrite.TabIndex = 15;
            this.btnTmpWrite.Text = "WriteDataToFile";
            this.btnTmpWrite.UseVisualStyleBackColor = true;
            this.btnTmpWrite.Click += new System.EventHandler(this.btnTmpWrite_Click);
            // 
            // btnTmpRead
            // 
            this.btnTmpRead.Location = new System.Drawing.Point(215, 329);
            this.btnTmpRead.Name = "btnTmpRead";
            this.btnTmpRead.Size = new System.Drawing.Size(88, 23);
            this.btnTmpRead.TabIndex = 14;
            this.btnTmpRead.Text = "ReadDataToPC";
            this.btnTmpRead.UseVisualStyleBackColor = true;
            this.btnTmpRead.Click += new System.EventHandler(this.btnTmpRead_Click);
            // 
            // lvTmp
            // 
            this.lvTmp.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader17,
            this.columnHeader18,
            this.columnHeader19,
            this.columnHeader20,
            this.columnHeader21});
            this.lvTmp.GridLines = true;
            this.lvTmp.Location = new System.Drawing.Point(6, 6);
            this.lvTmp.Name = "lvTmp";
            this.lvTmp.Size = new System.Drawing.Size(669, 280);
            this.lvTmp.TabIndex = 1;
            this.lvTmp.UseCompatibleStateImageBehavior = false;
            this.lvTmp.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader17
            // 
            this.columnHeader17.Text = "Size";
            this.columnHeader17.Width = 53;
            // 
            // columnHeader18
            // 
            this.columnHeader18.Text = "PIN";
            this.columnHeader18.Width = 45;
            // 
            // columnHeader19
            // 
            this.columnHeader19.Text = "FingerID";
            this.columnHeader19.Width = 72;
            // 
            // columnHeader20
            // 
            this.columnHeader20.Text = "Valid";
            this.columnHeader20.Width = 87;
            // 
            // columnHeader21
            // 
            this.columnHeader21.Text = "Template";
            this.columnHeader21.Width = 111;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.label6);
            this.tabPage4.Controls.Add(this.lvTmp10);
            this.tabPage4.Controls.Add(this.btnTmp10Write);
            this.tabPage4.Controls.Add(this.btnTmp10Read);
            this.tabPage4.Location = new System.Drawing.Point(4, 21);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(680, 370);
            this.tabPage4.TabIndex = 6;
            this.tabPage4.Text = "Tmp10.0";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(95, 302);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(497, 12);
            this.label6.TabIndex = 27;
            this.label6.Text = "It is for fingerprint templates management.(For devices with 10.0 arithmetic only" +
                ")";
            // 
            // lvTmp10
            // 
            this.lvTmp10.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader42,
            this.columnHeader43,
            this.columnHeader44,
            this.columnHeader45,
            this.columnHeader46});
            this.lvTmp10.GridLines = true;
            this.lvTmp10.Location = new System.Drawing.Point(6, 6);
            this.lvTmp10.Name = "lvTmp10";
            this.lvTmp10.Size = new System.Drawing.Size(669, 280);
            this.lvTmp10.TabIndex = 13;
            this.lvTmp10.UseCompatibleStateImageBehavior = false;
            this.lvTmp10.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader42
            // 
            this.columnHeader42.Text = "Size";
            this.columnHeader42.Width = 53;
            // 
            // columnHeader43
            // 
            this.columnHeader43.Text = "PIN";
            this.columnHeader43.Width = 45;
            // 
            // columnHeader44
            // 
            this.columnHeader44.Text = "FingerID";
            this.columnHeader44.Width = 72;
            // 
            // columnHeader45
            // 
            this.columnHeader45.Text = "Flag";
            this.columnHeader45.Width = 87;
            // 
            // columnHeader46
            // 
            this.columnHeader46.Text = "Template";
            this.columnHeader46.Width = 320;
            // 
            // btnTmp10Write
            // 
            this.btnTmp10Write.Location = new System.Drawing.Point(351, 329);
            this.btnTmp10Write.Name = "btnTmp10Write";
            this.btnTmp10Write.Size = new System.Drawing.Size(106, 23);
            this.btnTmp10Write.TabIndex = 12;
            this.btnTmp10Write.Text = "WriteDataToFile";
            this.btnTmp10Write.UseVisualStyleBackColor = true;
            this.btnTmp10Write.Click += new System.EventHandler(this.btnTmp10Write_Click);
            // 
            // btnTmp10Read
            // 
            this.btnTmp10Read.Location = new System.Drawing.Point(215, 329);
            this.btnTmp10Read.Name = "btnTmp10Read";
            this.btnTmp10Read.Size = new System.Drawing.Size(88, 23);
            this.btnTmp10Read.TabIndex = 11;
            this.btnTmp10Read.Text = "ReadDataToPC";
            this.btnTmp10Read.UseVisualStyleBackColor = true;
            this.btnTmp10Read.Click += new System.EventHandler(this.btnTmp10Read_Click);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.label9);
            this.tabPage5.Controls.Add(this.btnSSRSMSWrite);
            this.tabPage5.Controls.Add(this.btnSSRSMSRead);
            this.tabPage5.Controls.Add(this.lvSSRSMS);
            this.tabPage5.Location = new System.Drawing.Point(4, 21);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(680, 370);
            this.tabPage5.TabIndex = 8;
            this.tabPage5.Text = "SMS(TFT)";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(230, 302);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(221, 12);
            this.label9.TabIndex = 34;
            this.label9.Text = "It is for short messages management.";
            // 
            // btnSSRSMSWrite
            // 
            this.btnSSRSMSWrite.Location = new System.Drawing.Point(351, 329);
            this.btnSSRSMSWrite.Name = "btnSSRSMSWrite";
            this.btnSSRSMSWrite.Size = new System.Drawing.Size(106, 23);
            this.btnSSRSMSWrite.TabIndex = 33;
            this.btnSSRSMSWrite.Text = "WriteDataToFile";
            this.btnSSRSMSWrite.UseVisualStyleBackColor = true;
            this.btnSSRSMSWrite.Click += new System.EventHandler(this.btnSSRSMSWrite_Click);
            // 
            // btnSSRSMSRead
            // 
            this.btnSSRSMSRead.Location = new System.Drawing.Point(215, 329);
            this.btnSSRSMSRead.Name = "btnSSRSMSRead";
            this.btnSSRSMSRead.Size = new System.Drawing.Size(88, 23);
            this.btnSSRSMSRead.TabIndex = 32;
            this.btnSSRSMSRead.Text = "ReadDataToPC";
            this.btnSSRSMSRead.UseVisualStyleBackColor = true;
            this.btnSSRSMSRead.Click += new System.EventHandler(this.btnSSRSMSRead_Click);
            // 
            // lvSSRSMS
            // 
            this.lvSSRSMS.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader55,
            this.columnHeader56,
            this.columnHeader57,
            this.columnHeader58,
            this.columnHeader59,
            this.columnHeader60});
            this.lvSSRSMS.GridLines = true;
            this.lvSSRSMS.Location = new System.Drawing.Point(6, 6);
            this.lvSSRSMS.Name = "lvSSRSMS";
            this.lvSSRSMS.Size = new System.Drawing.Size(669, 280);
            this.lvSSRSMS.TabIndex = 29;
            this.lvSSRSMS.UseCompatibleStateImageBehavior = false;
            this.lvSSRSMS.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader55
            // 
            this.columnHeader55.Text = "Tag";
            this.columnHeader55.Width = 55;
            // 
            // columnHeader56
            // 
            this.columnHeader56.Text = "ID";
            this.columnHeader56.Width = 44;
            // 
            // columnHeader57
            // 
            this.columnHeader57.Text = "ValidMinutes";
            this.columnHeader57.Width = 97;
            // 
            // columnHeader58
            // 
            this.columnHeader58.Text = "Reserved";
            this.columnHeader58.Width = 82;
            // 
            // columnHeader59
            // 
            this.columnHeader59.Text = "StartTime";
            this.columnHeader59.Width = 139;
            // 
            // columnHeader60
            // 
            this.columnHeader60.Text = "Content";
            this.columnHeader60.Width = 224;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.label10);
            this.tabPage6.Controls.Add(this.btnUDataWrite);
            this.tabPage6.Controls.Add(this.btnUDataRead);
            this.tabPage6.Controls.Add(this.lvUData);
            this.tabPage6.Location = new System.Drawing.Point(4, 21);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(680, 370);
            this.tabPage6.TabIndex = 9;
            this.tabPage6.Text = "UData";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(140, 302);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(401, 12);
            this.label10.TabIndex = 36;
            this.label10.Text = "It is for relationship management between short message and users.";
            // 
            // btnUDataWrite
            // 
            this.btnUDataWrite.Location = new System.Drawing.Point(351, 329);
            this.btnUDataWrite.Name = "btnUDataWrite";
            this.btnUDataWrite.Size = new System.Drawing.Size(106, 23);
            this.btnUDataWrite.TabIndex = 35;
            this.btnUDataWrite.Text = "WriteDataToFile";
            this.btnUDataWrite.UseVisualStyleBackColor = true;
            this.btnUDataWrite.Click += new System.EventHandler(this.btnUDataWrite_Click);
            // 
            // btnUDataRead
            // 
            this.btnUDataRead.Location = new System.Drawing.Point(215, 329);
            this.btnUDataRead.Name = "btnUDataRead";
            this.btnUDataRead.Size = new System.Drawing.Size(88, 23);
            this.btnUDataRead.TabIndex = 34;
            this.btnUDataRead.Text = "ReadDataToPC";
            this.btnUDataRead.UseVisualStyleBackColor = true;
            this.btnUDataRead.Click += new System.EventHandler(this.btnUDataRead_Click);
            // 
            // lvUData
            // 
            this.lvUData.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader53,
            this.columnHeader54});
            this.lvUData.GridLines = true;
            this.lvUData.Location = new System.Drawing.Point(206, 6);
            this.lvUData.Name = "lvUData";
            this.lvUData.Size = new System.Drawing.Size(265, 280);
            this.lvUData.TabIndex = 30;
            this.lvUData.UseCompatibleStateImageBehavior = false;
            this.lvUData.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader53
            // 
            this.columnHeader53.Text = "PIN";
            this.columnHeader53.Width = 69;
            // 
            // columnHeader54
            // 
            this.columnHeader54.Text = "SmsID";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::UdiskData.Properties.Resources.top750;
            this.pictureBox1.Location = new System.Drawing.Point(-3, -2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(743, 30);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // UDiskDataMain
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(740, 466);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox1);
            this.Name = "UDiskDataMain";
            this.Text = "UDisk Data Management";
            this.groupBox1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.ListView lvTmp;
        private System.Windows.Forms.ColumnHeader columnHeader17;
        private System.Windows.Forms.ColumnHeader columnHeader18;
        private System.Windows.Forms.ColumnHeader columnHeader19;
        private System.Windows.Forms.ColumnHeader columnHeader20;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Button btnSSR_UserWrite;
        private System.Windows.Forms.Button btnSSR_UserRead;
        private System.Windows.Forms.ListView lvSSRUser;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.ColumnHeader columnHeader15;
        private System.Windows.Forms.ColumnHeader columnHeader16;
        private System.Windows.Forms.Button btnTmpWrite;
        private System.Windows.Forms.Button btnTmpRead;
        private System.Windows.Forms.ColumnHeader columnHeader21;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnSSRAttLogWrite;
        private System.Windows.Forms.Button btnSSRAttLogRead;
        private System.Windows.Forms.ListView lvSSRAttLog;
        private System.Windows.Forms.ColumnHeader columnHeader22;
        private System.Windows.Forms.ColumnHeader columnHeader23;
        private System.Windows.Forms.ColumnHeader columnHeader24;
        private System.Windows.Forms.ColumnHeader columnHeader31;
        private System.Windows.Forms.ColumnHeader columnHeader32;
        private System.Windows.Forms.ColumnHeader columnHeader33;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.ListView lvTmp10;
        private System.Windows.Forms.ColumnHeader columnHeader42;
        private System.Windows.Forms.ColumnHeader columnHeader43;
        private System.Windows.Forms.ColumnHeader columnHeader44;
        private System.Windows.Forms.ColumnHeader columnHeader45;
        private System.Windows.Forms.ColumnHeader columnHeader46;
        private System.Windows.Forms.Button btnTmp10Write;
        private System.Windows.Forms.Button btnTmp10Read;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Button btnUDataWrite;
        private System.Windows.Forms.Button btnUDataRead;
        private System.Windows.Forms.ListView lvUData;
        private System.Windows.Forms.ColumnHeader columnHeader53;
        private System.Windows.Forms.ColumnHeader columnHeader54;
        private System.Windows.Forms.Button btnSSRSMSWrite;
        private System.Windows.Forms.Button btnSSRSMSRead;
        private System.Windows.Forms.ListView lvSSRSMS;
        private System.Windows.Forms.ColumnHeader columnHeader55;
        private System.Windows.Forms.ColumnHeader columnHeader56;
        private System.Windows.Forms.ColumnHeader columnHeader57;
        private System.Windows.Forms.ColumnHeader columnHeader58;
        private System.Windows.Forms.ColumnHeader columnHeader59;
        private System.Windows.Forms.ColumnHeader columnHeader60;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
    }
}

