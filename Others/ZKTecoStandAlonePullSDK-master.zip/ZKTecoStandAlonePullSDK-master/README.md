# ZKTecoStandAlonePullSDK
Standalone SDK 6.3.1.37( Include Pull SDK 2.2.0.219) https://www.zkteco.com/en/download_catgory/46.html

I just wanted to have the ZKTeco Standalone and Pull SDK and demos in a decent repository, not in a zip file (it looks like ZKTeco has not yet modernized to distribute software in a proper way).