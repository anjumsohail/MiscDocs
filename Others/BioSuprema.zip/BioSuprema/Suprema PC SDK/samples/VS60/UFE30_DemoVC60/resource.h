//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by UFE30_Demo.rc
//
#define IDD_UFE30_DEMO_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDC_SCANNER_LIST                1001
#define IDC_INIT                        1002
#define IDC_UNINIT                      1003
#define IDC_IMAGE_FRAME                 1004
#define IDC_CAPTURE_SINGLE              1005
#define IDC_EXTRACTION                  1006
#define IDC_EXTRACT                     1006
#define IDC_IDENTIFY                    1007
#define IDC_VERIFY                      1008
#define IDC_MESSAGE_EDIT                1009
#define IDC_BRIGHTNESS                  1010
#define IDC_ENROLL                      1011
#define IDC_SENSITIVITY                 1012
#define IDC_START_CAPTURING             1013
#define IDC_BRIGHTNESS_SPIN             1014
#define IDC_SENSITIVITY_SPIN            1015
#define IDC_ENROLL_QUALITY              1016
#define IDC_ABORT_CAPTURING             1017
#define IDC_TIMEOUT                     1018
#define IDC_SECURITY_LEVEL              1019
#define IDC_FAST_MODE                   1020
#define IDC_DETECT_CORE                 1021
#define IDC_CLEAR_MESSAGE               1022
#define IDC_ID                          1023
#define IDC_SAVE_TEMPLATE               1024
#define IDC_SAVE_IMAGE                  1025
#define IDC_UPDATE                      1026
#define IDC_TYPE                        1027
#define IDC_MATCHING_TYPE               1028

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
