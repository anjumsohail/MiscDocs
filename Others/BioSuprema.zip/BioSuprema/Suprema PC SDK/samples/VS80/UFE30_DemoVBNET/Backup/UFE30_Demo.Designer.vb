<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UFE30_Demo
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim btnUpdate As System.Windows.Forms.Button
        Dim btnSaveImage As System.Windows.Forms.Button
        Dim btnSaveTemplate As System.Windows.Forms.Button
        Dim btnIdentify As System.Windows.Forms.Button
        Dim btnVerify As System.Windows.Forms.Button
        Dim btnCaptureSingle As System.Windows.Forms.Button
        Dim btnAbortCapturing As System.Windows.Forms.Button
        Dim btnEnroll As System.Windows.Forms.Button
        Dim btnExtract As System.Windows.Forms.Button
        Dim btnStartCapturing As System.Windows.Forms.Button
        Dim btnClear As System.Windows.Forms.Button
        Dim btnUninit As System.Windows.Forms.Button
        Dim btnInit As System.Windows.Forms.Button
        Me.groupBox3 = New System.Windows.Forms.GroupBox
        Me.cbID = New System.Windows.Forms.ComboBox
        Me.cbFastMode = New System.Windows.Forms.CheckBox
        Me.cbSecurityLevel = New System.Windows.Forms.ComboBox
        Me.label7 = New System.Windows.Forms.Label
        Me.label6 = New System.Windows.Forms.Label
        Me.groupBox2 = New System.Windows.Forms.GroupBox
        Me.cbEnrollQuality = New System.Windows.Forms.ComboBox
        Me.label5 = New System.Windows.Forms.Label
        Me.groupBox1 = New System.Windows.Forms.GroupBox
        Me.cbDetectCore = New System.Windows.Forms.CheckBox
        Me.nudSensitivity = New System.Windows.Forms.NumericUpDown
        Me.nudBrightness = New System.Windows.Forms.NumericUpDown
        Me.label4 = New System.Windows.Forms.Label
        Me.label3 = New System.Windows.Forms.Label
        Me.cbTimeout = New System.Windows.Forms.ComboBox
        Me.label2 = New System.Windows.Forms.Label
        Me.lbScannerList = New System.Windows.Forms.ListBox
        Me.label1 = New System.Windows.Forms.Label
        Me.pbImageFrame = New System.Windows.Forms.PictureBox
        Me.tbxMessage = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.cbScanTemplateType = New System.Windows.Forms.ComboBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.cbMatchTemplateType = New System.Windows.Forms.ComboBox
        btnUpdate = New System.Windows.Forms.Button
        btnSaveImage = New System.Windows.Forms.Button
        btnSaveTemplate = New System.Windows.Forms.Button
        btnIdentify = New System.Windows.Forms.Button
        btnVerify = New System.Windows.Forms.Button
        btnCaptureSingle = New System.Windows.Forms.Button
        btnAbortCapturing = New System.Windows.Forms.Button
        btnEnroll = New System.Windows.Forms.Button
        btnExtract = New System.Windows.Forms.Button
        btnStartCapturing = New System.Windows.Forms.Button
        btnClear = New System.Windows.Forms.Button
        btnUninit = New System.Windows.Forms.Button
        btnInit = New System.Windows.Forms.Button
        Me.groupBox3.SuspendLayout()
        Me.groupBox2.SuspendLayout()
        Me.groupBox1.SuspendLayout()
        CType(Me.nudSensitivity, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudBrightness, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbImageFrame, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnUpdate
        '
        btnUpdate.Location = New System.Drawing.Point(77, 12)
        btnUpdate.Name = "btnUpdate"
        btnUpdate.Size = New System.Drawing.Size(60, 24)
        btnUpdate.TabIndex = 31
        btnUpdate.Text = "Update"
        btnUpdate.UseVisualStyleBackColor = True
        AddHandler btnUpdate.Click, AddressOf Me.btnUpdate_Click
        '
        'btnSaveImage
        '
        btnSaveImage.Location = New System.Drawing.Point(325, 424)
        btnSaveImage.Name = "btnSaveImage"
        btnSaveImage.Size = New System.Drawing.Size(104, 28)
        btnSaveImage.TabIndex = 30
        btnSaveImage.Text = "Save Image"
        btnSaveImage.UseVisualStyleBackColor = True
        AddHandler btnSaveImage.Click, AddressOf Me.btnSaveImage_Click
        '
        'btnSaveTemplate
        '
        btnSaveTemplate.Location = New System.Drawing.Point(213, 424)
        btnSaveTemplate.Name = "btnSaveTemplate"
        btnSaveTemplate.Size = New System.Drawing.Size(104, 28)
        btnSaveTemplate.TabIndex = 29
        btnSaveTemplate.Text = "Save Template"
        btnSaveTemplate.UseVisualStyleBackColor = True
        AddHandler btnSaveTemplate.Click, AddressOf Me.btnSaveTemplate_Click
        '
        'btnIdentify
        '
        btnIdentify.Location = New System.Drawing.Point(124, 120)
        btnIdentify.Name = "btnIdentify"
        btnIdentify.Size = New System.Drawing.Size(96, 20)
        btnIdentify.TabIndex = 15
        btnIdentify.Text = "Identify"
        btnIdentify.UseVisualStyleBackColor = True
        AddHandler btnIdentify.Click, AddressOf Me.btnIdentify_Click
        '
        'btnVerify
        '
        btnVerify.Location = New System.Drawing.Point(124, 92)
        btnVerify.Name = "btnVerify"
        btnVerify.Size = New System.Drawing.Size(96, 20)
        btnVerify.TabIndex = 13
        btnVerify.Text = "Verify"
        btnVerify.UseVisualStyleBackColor = True
        AddHandler btnVerify.Click, AddressOf Me.btnVerify_Click
        '
        'btnCaptureSingle
        '
        btnCaptureSingle.Location = New System.Drawing.Point(8, 52)
        btnCaptureSingle.Name = "btnCaptureSingle"
        btnCaptureSingle.Size = New System.Drawing.Size(96, 20)
        btnCaptureSingle.TabIndex = 14
        btnCaptureSingle.Text = "Capture Single"
        btnCaptureSingle.UseVisualStyleBackColor = True
        AddHandler btnCaptureSingle.Click, AddressOf Me.btnCaptureSingle_Click
        '
        'btnAbortCapturing
        '
        btnAbortCapturing.Location = New System.Drawing.Point(108, 24)
        btnAbortCapturing.Name = "btnAbortCapturing"
        btnAbortCapturing.Size = New System.Drawing.Size(74, 20)
        btnAbortCapturing.TabIndex = 13
        btnAbortCapturing.Text = "Abort"
        btnAbortCapturing.UseVisualStyleBackColor = True
        AddHandler btnAbortCapturing.Click, AddressOf Me.btnAbortCapturing_Click
        '
        'btnEnroll
        '
        btnEnroll.Location = New System.Drawing.Point(76, 116)
        btnEnroll.Name = "btnEnroll"
        btnEnroll.Size = New System.Drawing.Size(104, 20)
        btnEnroll.TabIndex = 12
        btnEnroll.Text = "Enroll"
        btnEnroll.UseVisualStyleBackColor = True
        AddHandler btnEnroll.Click, AddressOf Me.btnEnroll_Click
        '
        'btnExtract
        '
        btnExtract.Location = New System.Drawing.Point(108, 52)
        btnExtract.Name = "btnExtract"
        btnExtract.Size = New System.Drawing.Size(72, 20)
        btnExtract.TabIndex = 11
        btnExtract.Text = "Extract"
        btnExtract.UseVisualStyleBackColor = True
        AddHandler btnExtract.Click, AddressOf Me.btnExtract_Click
        '
        'btnStartCapturing
        '
        btnStartCapturing.Location = New System.Drawing.Point(8, 24)
        btnStartCapturing.Name = "btnStartCapturing"
        btnStartCapturing.Size = New System.Drawing.Size(96, 20)
        btnStartCapturing.TabIndex = 10
        btnStartCapturing.Text = "Start Capturing"
        btnStartCapturing.UseVisualStyleBackColor = True
        AddHandler btnStartCapturing.Click, AddressOf Me.btnStartCapturing_Click
        '
        'btnClear
        '
        btnClear.Location = New System.Drawing.Point(393, 471)
        btnClear.Name = "btnClear"
        btnClear.Size = New System.Drawing.Size(44, 68)
        btnClear.TabIndex = 22
        btnClear.Text = "Clear"
        btnClear.UseVisualStyleBackColor = True
        AddHandler btnClear.Click, AddressOf Me.btnClear_Click
        '
        'btnUninit
        '
        btnUninit.Location = New System.Drawing.Point(141, 12)
        btnUninit.Name = "btnUninit"
        btnUninit.Size = New System.Drawing.Size(60, 24)
        btnUninit.TabIndex = 20
        btnUninit.Text = "Uninit"
        btnUninit.UseVisualStyleBackColor = True
        AddHandler btnUninit.Click, AddressOf Me.btnUninit_Click
        '
        'btnInit
        '
        btnInit.Location = New System.Drawing.Point(13, 12)
        btnInit.Name = "btnInit"
        btnInit.Size = New System.Drawing.Size(60, 24)
        btnInit.TabIndex = 19
        btnInit.Text = "Init"
        btnInit.UseVisualStyleBackColor = True
        AddHandler btnInit.Click, AddressOf Me.btnInit_Click
        '
        'groupBox3
        '
        Me.groupBox3.Controls.Add(btnIdentify)
        Me.groupBox3.Controls.Add(btnVerify)
        Me.groupBox3.Controls.Add(Me.cbID)
        Me.groupBox3.Controls.Add(Me.cbFastMode)
        Me.groupBox3.Controls.Add(Me.cbMatchTemplateType)
        Me.groupBox3.Controls.Add(Me.cbSecurityLevel)
        Me.groupBox3.Controls.Add(Me.label7)
        Me.groupBox3.Controls.Add(Me.Label9)
        Me.groupBox3.Controls.Add(Me.label6)
        Me.groupBox3.Location = New System.Drawing.Point(209, 272)
        Me.groupBox3.Name = "groupBox3"
        Me.groupBox3.Size = New System.Drawing.Size(228, 146)
        Me.groupBox3.TabIndex = 28
        Me.groupBox3.TabStop = False
        Me.groupBox3.Text = "Match"
        '
        'cbID
        '
        Me.cbID.FormattingEnabled = True
        Me.cbID.Location = New System.Drawing.Point(64, 103)
        Me.cbID.Name = "cbID"
        Me.cbID.Size = New System.Drawing.Size(44, 20)
        Me.cbID.TabIndex = 13
        '
        'cbFastMode
        '
        Me.cbFastMode.AutoSize = True
        Me.cbFastMode.Location = New System.Drawing.Point(10, 81)
        Me.cbFastMode.Name = "cbFastMode"
        Me.cbFastMode.Size = New System.Drawing.Size(84, 16)
        Me.cbFastMode.TabIndex = 7
        Me.cbFastMode.Text = "Fast Mode"
        Me.cbFastMode.UseVisualStyleBackColor = True
        '
        'cbSecurityLevel
        '
        Me.cbSecurityLevel.FormattingEnabled = True
        Me.cbSecurityLevel.Items.AddRange(New Object() {"1 (FAR1/100)", "2 (1/1,000)", "3 (1/10,000)", "4*(1/100,000)", "5 (1/1,000,000)", "6 (1/10,000,000)", "7 (1/100,000,000)"})
        Me.cbSecurityLevel.Location = New System.Drawing.Point(96, 20)
        Me.cbSecurityLevel.Name = "cbSecurityLevel"
        Me.cbSecurityLevel.Size = New System.Drawing.Size(120, 20)
        Me.cbSecurityLevel.TabIndex = 13
        '
        'label7
        '
        Me.label7.AutoSize = True
        Me.label7.Location = New System.Drawing.Point(6, 111)
        Me.label7.Name = "label7"
        Me.label7.Size = New System.Drawing.Size(52, 12)
        Me.label7.TabIndex = 14
        Me.label7.Text = "Enroll ID"
        '
        'label6
        '
        Me.label6.AutoSize = True
        Me.label6.Location = New System.Drawing.Point(8, 24)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(85, 12)
        Me.label6.TabIndex = 13
        Me.label6.Text = "Security Level"
        '
        'groupBox2
        '
        Me.groupBox2.Controls.Add(btnCaptureSingle)
        Me.groupBox2.Controls.Add(btnAbortCapturing)
        Me.groupBox2.Controls.Add(btnEnroll)
        Me.groupBox2.Controls.Add(btnExtract)
        Me.groupBox2.Controls.Add(btnStartCapturing)
        Me.groupBox2.Controls.Add(Me.cbEnrollQuality)
        Me.groupBox2.Controls.Add(Me.label5)
        Me.groupBox2.Location = New System.Drawing.Point(13, 304)
        Me.groupBox2.Name = "groupBox2"
        Me.groupBox2.Size = New System.Drawing.Size(188, 148)
        Me.groupBox2.TabIndex = 27
        Me.groupBox2.TabStop = False
        Me.groupBox2.Text = "Enroll"
        '
        'cbEnrollQuality
        '
        Me.cbEnrollQuality.FormattingEnabled = True
        Me.cbEnrollQuality.Items.AddRange(New Object() {"30", "40", "50*", "60", "70"})
        Me.cbEnrollQuality.Location = New System.Drawing.Point(112, 88)
        Me.cbEnrollQuality.Name = "cbEnrollQuality"
        Me.cbEnrollQuality.Size = New System.Drawing.Size(44, 20)
        Me.cbEnrollQuality.TabIndex = 7
        '
        'label5
        '
        Me.label5.AutoSize = True
        Me.label5.Location = New System.Drawing.Point(8, 92)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(104, 12)
        Me.label5.TabIndex = 7
        Me.label5.Text = "Enroll Quality (%)"
        '
        'groupBox1
        '
        Me.groupBox1.Controls.Add(Me.cbDetectCore)
        Me.groupBox1.Controls.Add(Me.nudSensitivity)
        Me.groupBox1.Controls.Add(Me.nudBrightness)
        Me.groupBox1.Controls.Add(Me.label4)
        Me.groupBox1.Controls.Add(Me.cbScanTemplateType)
        Me.groupBox1.Controls.Add(Me.label3)
        Me.groupBox1.Controls.Add(Me.cbTimeout)
        Me.groupBox1.Controls.Add(Me.Label8)
        Me.groupBox1.Controls.Add(Me.label2)
        Me.groupBox1.Location = New System.Drawing.Point(13, 148)
        Me.groupBox1.Name = "groupBox1"
        Me.groupBox1.Size = New System.Drawing.Size(188, 150)
        Me.groupBox1.TabIndex = 26
        Me.groupBox1.TabStop = False
        Me.groupBox1.Text = "Scanner Parameters"
        '
        'cbDetectCore
        '
        Me.cbDetectCore.AutoSize = True
        Me.cbDetectCore.Location = New System.Drawing.Point(8, 96)
        Me.cbDetectCore.Name = "cbDetectCore"
        Me.cbDetectCore.Size = New System.Drawing.Size(90, 16)
        Me.cbDetectCore.TabIndex = 6
        Me.cbDetectCore.Text = "Detect Core"
        Me.cbDetectCore.UseVisualStyleBackColor = True
        '
        'nudSensitivity
        '
        Me.nudSensitivity.Location = New System.Drawing.Point(92, 68)
        Me.nudSensitivity.Name = "nudSensitivity"
        Me.nudSensitivity.Size = New System.Drawing.Size(48, 21)
        Me.nudSensitivity.TabIndex = 5
        '
        'nudBrightness
        '
        Me.nudBrightness.Location = New System.Drawing.Point(92, 44)
        Me.nudBrightness.Name = "nudBrightness"
        Me.nudBrightness.Size = New System.Drawing.Size(48, 21)
        Me.nudBrightness.TabIndex = 4
        '
        'label4
        '
        Me.label4.AutoSize = True
        Me.label4.Location = New System.Drawing.Point(8, 72)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(62, 12)
        Me.label4.TabIndex = 3
        Me.label4.Text = "Sensitivity"
        '
        'label3
        '
        Me.label3.AutoSize = True
        Me.label3.Location = New System.Drawing.Point(8, 48)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(65, 12)
        Me.label3.TabIndex = 2
        Me.label3.Text = "Brightness"
        '
        'cbTimeout
        '
        Me.cbTimeout.FormattingEnabled = True
        Me.cbTimeout.Items.AddRange(New Object() {"0", "1", "2", "3", "4", "5*"})
        Me.cbTimeout.Location = New System.Drawing.Point(76, 21)
        Me.cbTimeout.Name = "cbTimeout"
        Me.cbTimeout.Size = New System.Drawing.Size(48, 20)
        Me.cbTimeout.TabIndex = 1
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Location = New System.Drawing.Point(8, 24)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(51, 12)
        Me.label2.TabIndex = 0
        Me.label2.Text = "Timeout"
        '
        'lbScannerList
        '
        Me.lbScannerList.FormattingEnabled = True
        Me.lbScannerList.ItemHeight = 12
        Me.lbScannerList.Location = New System.Drawing.Point(13, 64)
        Me.lbScannerList.Name = "lbScannerList"
        Me.lbScannerList.Size = New System.Drawing.Size(188, 76)
        Me.lbScannerList.TabIndex = 25
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Location = New System.Drawing.Point(13, 44)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(76, 12)
        Me.label1.TabIndex = 24
        Me.label1.Text = "Scanner List"
        '
        'pbImageFrame
        '
        Me.pbImageFrame.BackColor = System.Drawing.SystemColors.Control
        Me.pbImageFrame.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbImageFrame.Location = New System.Drawing.Point(209, 12)
        Me.pbImageFrame.Name = "pbImageFrame"
        Me.pbImageFrame.Size = New System.Drawing.Size(228, 252)
        Me.pbImageFrame.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbImageFrame.TabIndex = 23
        Me.pbImageFrame.TabStop = False
        '
        'tbxMessage
        '
        Me.tbxMessage.Location = New System.Drawing.Point(13, 471)
        Me.tbxMessage.Multiline = True
        Me.tbxMessage.Name = "tbxMessage"
        Me.tbxMessage.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.tbxMessage.Size = New System.Drawing.Size(376, 68)
        Me.tbxMessage.TabIndex = 21
        Me.tbxMessage.WordWrap = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(6, 124)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(81, 12)
        Me.Label8.TabIndex = 13
        Me.Label8.Text = "template type"
        '
        'cbScanTemplateType
        '
        Me.cbScanTemplateType.FormattingEnabled = True
        Me.cbScanTemplateType.Items.AddRange(New Object() {"suprema", "iso19794_2", "ansi378"})
        Me.cbScanTemplateType.Location = New System.Drawing.Point(92, 118)
        Me.cbScanTemplateType.Name = "cbScanTemplateType"
        Me.cbScanTemplateType.Size = New System.Drawing.Size(90, 20)
        Me.cbScanTemplateType.TabIndex = 13
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(8, 52)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(81, 12)
        Me.Label9.TabIndex = 13
        Me.Label9.Text = "template type"
        '
        'cbMatchTemplateType
        '
        Me.cbMatchTemplateType.FormattingEnabled = True
        Me.cbMatchTemplateType.Items.AddRange(New Object() {"suprema", "iso19794_2", "ansi378"})
        Me.cbMatchTemplateType.Location = New System.Drawing.Point(96, 52)
        Me.cbMatchTemplateType.Name = "cbMatchTemplateType"
        Me.cbMatchTemplateType.Size = New System.Drawing.Size(120, 20)
        Me.cbMatchTemplateType.TabIndex = 13
        '
        'UFE30_Demo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.ClientSize = New System.Drawing.Size(450, 551)
        Me.Controls.Add(btnUpdate)
        Me.Controls.Add(btnSaveImage)
        Me.Controls.Add(btnSaveTemplate)
        Me.Controls.Add(Me.groupBox3)
        Me.Controls.Add(Me.groupBox2)
        Me.Controls.Add(Me.groupBox1)
        Me.Controls.Add(Me.lbScannerList)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.pbImageFrame)
        Me.Controls.Add(btnClear)
        Me.Controls.Add(Me.tbxMessage)
        Me.Controls.Add(btnUninit)
        Me.Controls.Add(btnInit)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "UFE30_Demo"
        Me.Text = "Suprema PC SDK 3.1 Demo (VB.NET)"
        Me.groupBox3.ResumeLayout(False)
        Me.groupBox3.PerformLayout()
        Me.groupBox2.ResumeLayout(False)
        Me.groupBox2.PerformLayout()
        Me.groupBox1.ResumeLayout(False)
        Me.groupBox1.PerformLayout()
        CType(Me.nudSensitivity, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudBrightness, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbImageFrame, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents groupBox3 As System.Windows.Forms.GroupBox
    Private WithEvents cbID As System.Windows.Forms.ComboBox
    Private WithEvents cbFastMode As System.Windows.Forms.CheckBox
    Private WithEvents cbSecurityLevel As System.Windows.Forms.ComboBox
    Private WithEvents label7 As System.Windows.Forms.Label
    Private WithEvents label6 As System.Windows.Forms.Label
    Private WithEvents groupBox2 As System.Windows.Forms.GroupBox
    Private WithEvents cbEnrollQuality As System.Windows.Forms.ComboBox
    Private WithEvents label5 As System.Windows.Forms.Label
    Private WithEvents groupBox1 As System.Windows.Forms.GroupBox
    Private WithEvents cbDetectCore As System.Windows.Forms.CheckBox
    Private WithEvents nudSensitivity As System.Windows.Forms.NumericUpDown
    Private WithEvents nudBrightness As System.Windows.Forms.NumericUpDown
    Private WithEvents label4 As System.Windows.Forms.Label
    Private WithEvents label3 As System.Windows.Forms.Label
    Private WithEvents cbTimeout As System.Windows.Forms.ComboBox
    Private WithEvents label2 As System.Windows.Forms.Label
    Private WithEvents lbScannerList As System.Windows.Forms.ListBox
    Private WithEvents label1 As System.Windows.Forms.Label
    Private WithEvents pbImageFrame As System.Windows.Forms.PictureBox
    Private WithEvents tbxMessage As System.Windows.Forms.TextBox
    Private WithEvents cbMatchTemplateType As System.Windows.Forms.ComboBox
    Private WithEvents Label9 As System.Windows.Forms.Label
    Private WithEvents cbScanTemplateType As System.Windows.Forms.ComboBox
    Private WithEvents Label8 As System.Windows.Forms.Label

End Class
