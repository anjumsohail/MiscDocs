Imports System.IO
Imports Suprema

Public Class UFE30_Demo
    '==========================================================================='
    Private m_ScannerManager As UFScannerManager
    Private m_Matcher As UFMatcher = Nothing
    Private m_strError As String
    Private m_template As Byte()()
    Private m_template_size As Integer()
    Private m_template_num As Integer
    '
    Private Const MAX_TEMPLATE_SIZE As Integer = 384
    Private Const MAX_TEMPLATE_NUM As Integer = 50

    Private Sub UFE30_Demo_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        m_template = New Byte(MAX_TEMPLATE_NUM)() {}
        For i As Integer = 0 To MAX_TEMPLATE_NUM - 1
			m_template(i) = New Byte(MAX_TEMPLATE_SIZE) {}
        Next
        m_template_size = New Integer(MAX_TEMPLATE_NUM) {}
        m_template_num = 0

		m_ScannerManager = New UFScannerManager(Me)

        cbEnrollQuality.SelectedIndex = 2
        cbScanTemplateType.SelectedIndex = 0
        cbMatchTemplateType.SelectedIndex = 0

    End Sub

    Private Sub UFE30_Demo_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        btnUninit_Click(sender, e)
    End Sub
    '==========================================================================='

    '==========================================================================='
    Private Sub GetScannerTypeString(ByVal ScannerType As UFS_SCANNER_TYPE, ByRef strScannerType As String)
        If (ScannerType = UFS_SCANNER_TYPE.SFR200) Then
            strScannerType = "SFR200"
        ElseIf (ScannerType = UFS_SCANNER_TYPE.SFR300) Then
            strScannerType = "SFR300"
        ElseIf (ScannerType = UFS_SCANNER_TYPE.SFR300v2) Then
            strScannerType = "SFR300v2"
        Else
            strScannerType = "Error"
        End If
    End Sub

    Private Function GetCurrentScanner(ByRef Scanner As UFScanner) As Boolean
        Scanner = m_ScannerManager.Scanners(lbScannerList.SelectedIndex)
        If (Not Equals(Scanner, Nothing)) Then
            Return True
        Else
            tbxMessage.AppendText("Selected Scanner is not connected" & vbNewLine)
            Return False
        End If
    End Function

    Private Sub GetCurrentScannerSettings()
        Dim Scanner As UFScanner = Nothing
        If (GetCurrentScanner(Scanner) = False) Then
            Exit Sub
        End If

		' Unit of timeout is millisecond
		cbTimeout.SelectedIndex = Scanner.Timeout / 1000

        nudBrightness.Minimum = 0
        nudBrightness.Maximum = 255
        nudBrightness.Value = Scanner.Brightness

        nudSensitivity.Minimum = 0
        nudSensitivity.Maximum = 7
        nudSensitivity.Value = Scanner.Sensitivity

        cbDetectCore.Checked = Scanner.DetectCore
    End Sub

    Private Sub GetMatcherSettings(ByRef Matcher As UFMatcher)
		' Security level ranges from 1 to 7
		cbSecurityLevel.SelectedIndex = Matcher.SecurityLevel - 1

        cbFastMode.Checked = Matcher.FastMode
    End Sub

    Private Sub DrawCapturedImage(ByRef Scanner As UFScanner)
        Dim g As Graphics = pbImageFrame.CreateGraphics()
        Dim rect As Rectangle = New Rectangle(0, 0, pbImageFrame.Width, pbImageFrame.Height)
        Dim Resolution As Integer
        Try
            '
            'Scanner.DrawCaptureImageBuffer(g, rect, cbDetectCore.Checked);
            '
            Dim bitmap As Bitmap = Nothing
            Scanner.GetCaptureImageBuffer(bitmap, Resolution)
            pbImageFrame.Image = bitmap
        Finally
            g.Dispose()
        End Try
    End Sub
    '==========================================================================='

    '==========================================================================='
    Private Sub lbScannerList_SelectedValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lbScannerList.SelectedValueChanged
        GetCurrentScannerSettings()
    End Sub

    Private Sub cbTimeout_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbTimeout.SelectedIndexChanged
        Dim Scanner As UFScanner = Nothing
        If (GetCurrentScanner(Scanner) = False) Then
            Exit Sub
        End If
		' Unit of timeout is millisecond
		Scanner.Timeout = cbTimeout.SelectedIndex * 1000
    End Sub

    Private Sub nudBrightness_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles nudBrightness.ValueChanged
        Dim Scanner As UFScanner = Nothing
        If (GetCurrentScanner(Scanner) = False) Then
            Exit Sub
        End If
        Scanner.Brightness = nudBrightness.Value
    End Sub

    Private Sub nudSensitivity_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles nudSensitivity.ValueChanged
        Dim Scanner As UFScanner = Nothing
        If (GetCurrentScanner(Scanner) = False) Then
            Exit Sub
        End If
        Scanner.Sensitivity = nudSensitivity.Value
    End Sub

    Private Sub cbDetectCore_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbDetectCore.CheckedChanged
        Dim Scanner As UFScanner = Nothing
        If (GetCurrentScanner(Scanner) = False) Then
            Exit Sub
        End If
        Scanner.DetectCore = cbDetectCore.Checked
    End Sub

    Private Sub cbSecurityLevel_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbSecurityLevel.SelectedIndexChanged
        If (Not Equals(Nothing, m_Matcher)) Then
            ' Security level ranges from 1 to 7
            m_Matcher.SecurityLevel = cbSecurityLevel.SelectedIndex + 1
        End If
    End Sub
    Private Sub cbScanTemplateType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbScanTemplateType.SelectedIndexChanged

        ' template type 2001,2002,2003
        Dim Scanner As UFScanner = Nothing
        If (GetCurrentScanner(Scanner) = False) Then
            Exit Sub
        End If
        Select Case cbScanTemplateType.SelectedIndex

            Case 0
                Scanner.nTemplateType = 2001
            Case 1
                Scanner.nTemplateType = 2002
            Case 2
                Scanner.nTemplateType = 2003

        End Select

    End Sub
    Private Sub cbMatchTemplateType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbMatchTemplateType.SelectedIndexChanged
        If (Not Equals(Nothing, m_Matcher)) Then
            ' template type 2001,2002,2003
          
            Select Case cbMatchTemplateType.SelectedIndex

                Case 0
                    m_Matcher.nTemplateType = 2001

                Case 1
                    m_Matcher.nTemplateType = 2002

                Case 2
                    m_Matcher.nTemplateType = 2003


            End Select

        End If
    End Sub
    Private Sub cbFastMode_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbFastMode.CheckedChanged
        If (Not Equals(Nothing, m_Matcher)) Then
            m_Matcher.FastMode = cbFastMode.Checked
        End If
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        tbxMessage.Clear()
    End Sub
    '==========================================================================='

    '==========================================================================='
    Private Sub UpdateScannerList()
        Dim nScannerNumber As Integer = Nothing

        nScannerNumber = m_ScannerManager.Scanners.Count

        lbScannerList.Items.Clear()

        For i As Integer = 0 To nScannerNumber - 1
            Dim Scanner As UFScanner
            Dim ScannerType As UFS_SCANNER_TYPE = Nothing
            Dim strScannerType As String = Nothing
            Dim strID As String = Nothing
            Dim str_tmp As String = Nothing

            Scanner = m_ScannerManager.Scanners(i)

            tbxMessage.AppendText("Scanner " & i & " serial: " & Scanner.Serial & vbNewLine)

            ScannerType = Scanner.ScannerType
            strID = Scanner.ID
            GetScannerTypeString(ScannerType, strScannerType)

            str_tmp = i & ": " & strScannerType & " " & strID
            lbScannerList.Items.Add(str_tmp)
        Next

        If (nScannerNumber > 0) Then
            lbScannerList.SetSelected(0, True)
            GetCurrentScannerSettings()
        End If
    End Sub

    Private Sub ScannerEvent(ByVal sender As Object, ByVal e As UFScannerManagerScannerEventArgs)
        If (e.SensorOn) Then
            UpdateScannerList()
        Else
            UpdateScannerList()
        End If
    End Sub
    '==========================================================================='

    '==========================================================================='
    Private Sub btnInit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        '==========================================================================='
        ' Initilize scanners
        '==========================================================================='
        Dim ufs_res As UFS_STATUS
        Dim nScannerNumber As Integer

        Windows.Forms.Cursor.Current = Cursors.WaitCursor
        ufs_res = m_ScannerManager.Init()
        Windows.Forms.Cursor.Current = Me.Cursor
        If (ufs_res = UFS_STATUS.OK) Then
            tbxMessage.AppendText("UFScanner Init: OK" & vbNewLine)
        Else
            UFScanner.GetErrorString(ufs_res, m_strError)
            tbxMessage.AppendText("UFScanner Init: " & m_strError & vbNewLine)
            Exit Sub
        End If

        AddHandler m_ScannerManager.ScannerEvent, AddressOf ScannerEvent

        nScannerNumber = m_ScannerManager.Scanners.Count
        tbxMessage.AppendText("UFScanner GetScannerNumber: " & nScannerNumber & vbNewLine)

        UpdateScannerList()
        '==========================================================================='

        '==========================================================================='
        ' Create one matcher
        '==========================================================================='
        m_Matcher = New UFMatcher()

        GetMatcherSettings(m_Matcher)
        '==========================================================================='
    End Sub

    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim ufs_res As UFS_STATUS

        Windows.Forms.Cursor.Current = Cursors.WaitCursor
        ufs_res = m_ScannerManager.Update()
        Windows.Forms.Cursor.Current = Me.Cursor

        If (ufs_res = UFS_STATUS.OK) Then
            tbxMessage.AppendText("UFScanner Update: OK" & vbNewLine)
            UpdateScannerList()
        Else
            UFScanner.GetErrorString(ufs_res, m_strError)
            tbxMessage.AppendText("UFScanner Update: " & m_strError & vbNewLine)
        End If
    End Sub

    Private Sub btnUninit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        '==========================================================================='
        ' Uninit scanners
        '==========================================================================='
        Dim ufs_res As UFS_STATUS

        Windows.Forms.Cursor.Current = Cursors.WaitCursor
        ufs_res = m_ScannerManager.Uninit()
        Windows.Forms.Cursor.Current = Me.Cursor

        If (ufs_res = UFS_STATUS.OK) Then
            tbxMessage.AppendText("UFScanner Uninit: OK" & vbNewLine)
            RemoveHandler m_ScannerManager.ScannerEvent, AddressOf ScannerEvent
            lbScannerList.Items.Clear()
        Else
            UFScanner.GetErrorString(ufs_res, m_strError)
            tbxMessage.AppendText("UFScanner Uninit: " & m_strError & vbNewLine)
        End If

        pbImageFrame.Image = Nothing
        '==========================================================================='
    End Sub

    Private Delegate Sub _UpdatePictureBox(ByRef pbox As PictureBox, ByRef image As Bitmap)

    Public Sub UpdatePictureBox(ByRef pbox As PictureBox, ByRef image As Bitmap)
        If (pbox.InvokeRequired) Then
            Dim del As _UpdatePictureBox = New _UpdatePictureBox(AddressOf UpdatePictureBox)
            ' Call the function in the correct thread
            Dim params() As Object = New Object(1) {pbox, image}
            BeginInvoke(del, params)
        Else
            ' We are in the correct thread, so assign the image
            pbox.Image = image
        End If
    End Sub

    Public Sub CaptureEvent(ByVal sender As Object, ByVal e As UFScannerCaptureEventArgs)
        ' We cannot use pbImageFrame.Image directly from the different thread,
        ' so we use UpdatePictureBox() to update PictureBox indirectly
        UpdatePictureBox(pbImageFrame, e.ImageFrame)
    End Sub

    Private Sub btnStartCapturing_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim Scanner As UFScanner = Nothing
        Dim ufs_res As UFS_STATUS
        If (GetCurrentScanner(Scanner) = False) Then
            Exit Sub
        End If

        AddHandler Scanner.CaptureEvent, AddressOf CaptureEvent
        ufs_res = Scanner.StartCapturing()
        If (ufs_res = UFS_STATUS.OK) Then
            tbxMessage.AppendText("UFScanner StartCapturing: OK" & vbNewLine)
        Else
            UFScanner.GetErrorString(ufs_res, m_strError)
            tbxMessage.AppendText("UFScanner StartCapturing: " & m_strError & vbNewLine)
        End If
    End Sub

    Private Sub btnAbortCapturing_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim Scanner As UFScanner = Nothing
        Dim ufs_res As UFS_STATUS
        If (GetCurrentScanner(Scanner) = False) Then
            Exit Sub
        End If

        ufs_res = Scanner.AbortCapturing()
        If (ufs_res = UFS_STATUS.OK) Then
            tbxMessage.AppendText("UFScanner AbortCapturing: OK" & vbNewLine)
        Else
            UFScanner.GetErrorString(ufs_res, m_strError)
            tbxMessage.AppendText("UFScanner AbortCapturing: " & m_strError & vbNewLine)
        End If
    End Sub

    Private Sub btnCaptureSingle_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim Scanner As UFScanner = Nothing
        Dim ufs_res As UFS_STATUS
        If (GetCurrentScanner(Scanner) = False) Then
            Exit Sub
        End If

        Windows.Forms.Cursor.Current = Cursors.WaitCursor
        ufs_res = Scanner.CaptureSingleImage()
        Windows.Forms.Cursor.Current = Me.Cursor

        If (ufs_res = UFS_STATUS.OK) Then
            tbxMessage.AppendText("UFScanner CaptureSingleImage: OK" & vbNewLine)
            DrawCapturedImage(Scanner)
        Else
            UFScanner.GetErrorString(ufs_res, m_strError)
            tbxMessage.AppendText("UFScanner CaptureSingleImage: " & m_strError & vbNewLine)
        End If
    End Sub

    Private Sub btnExtract_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim Scanner As UFScanner = Nothing
        Dim ufs_res As UFS_STATUS
        If (GetCurrentScanner(Scanner) = False) Then
            Exit Sub
        End If

        Scanner.TemplateSize = MAX_TEMPLATE_SIZE
        Scanner.DetectCore = cbDetectCore.Checked

        Dim Template As Byte() = New Byte(MAX_TEMPLATE_SIZE) {}
        Dim TemplateSize As Integer = Nothing
        Dim EnrollQuality As Integer = Nothing

        Windows.Forms.Cursor.Current = Cursors.WaitCursor
        ufs_res = Scanner.Extract(Template, TemplateSize, EnrollQuality)
        Windows.Forms.Cursor.Current = Me.Cursor

        If (ufs_res = UFS_STATUS.OK) Then
            tbxMessage.AppendText("UFScanner Extract: OK" & vbNewLine)
            DrawCapturedImage(Scanner)
        Else
            UFScanner.GetErrorString(ufs_res, m_strError)
            tbxMessage.AppendText("UFScanner Extract: " & m_strError & vbNewLine)
        End If
    End Sub

    Private Sub btnEnroll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim Scanner As UFScanner = Nothing
        Dim ufs_res As UFS_STATUS
        Dim EnrollQuality As Integer = Nothing

        If (GetCurrentScanner(Scanner) = False) Then
            Exit Sub
        End If
        Scanner.ClearCaptureImageBuffer()

        tbxMessage.AppendText("Place Finger" & vbNewLine)

        While True
            ufs_res = Scanner.CaptureSingleImage()
            If (ufs_res <> UFS_STATUS.OK) Then
                UFScanner.GetErrorString(ufs_res, m_strError)
                tbxMessage.AppendText("UFScanner CaptureSingleImage: " & m_strError & vbNewLine)
                Exit Sub
            End If

            Select Case cbScanTemplateType.SelectedIndex

                Case 0
                    Scanner.nTemplateType = 2001

                Case 1
                    Scanner.nTemplateType = 2002

                Case 2
                    Scanner.nTemplateType = 2003


            End Select

            ufs_res = Scanner.Extract(m_template(m_template_num), m_template_size(m_template_num), EnrollQuality)
            If (ufs_res = UFS_STATUS.OK) Then
                tbxMessage.AppendText("UFScanner Extract: OK" & vbNewLine)
                DrawCapturedImage(Scanner)
                Exit While
            Else
                UFScanner.GetErrorString(ufs_res, m_strError)
                tbxMessage.AppendText("UFScanner Extract: " & m_strError & vbNewLine)
            End If
        End While

        If (EnrollQuality < cbEnrollQuality.SelectedIndex * 10 + 30) Then
            tbxMessage.AppendText("Too low quality [Q:" & EnrollQuality & "]" & vbNewLine)
            Exit Sub
        End If

        tbxMessage.AppendText("Enrollment success (No." & (m_template_num + 1) & ") [Q:" & EnrollQuality & "]" & vbNewLine)

        cbID.Items.Add(m_template_num + 1)
        If (m_template_num + 1 = MAX_TEMPLATE_NUM) Then
            tbxMessage.AppendText("Template memory is full" & vbNewLine)
        Else
            m_template_num += 1
        End If
    End Sub

    Private Sub btnVerify_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim Scanner As UFScanner = Nothing
        Dim ufs_res As UFS_STATUS
        Dim ufm_res As UFM_STATUS
        Dim Template As Byte() = New Byte(MAX_TEMPLATE_SIZE) {}
        Dim TemplateSize As Integer = Nothing
        Dim EnrollQuality As Integer = Nothing
        Dim VerifySucceed As Boolean = Nothing
        Dim SelectID As Integer

        SelectID = cbID.SelectedIndex
        If (SelectID = -1) Then
            tbxMessage.AppendText("Select Enroll ID" & vbCrLf)
            Exit Sub
        End If

        If (GetCurrentScanner(Scanner) = False) Then
            Exit Sub
        End If
        Scanner.ClearCaptureImageBuffer()

        tbxMessage.AppendText("Place Finger" & vbNewLine)

        ufs_res = Scanner.CaptureSingleImage()
        If (ufs_res <> UFS_STATUS.OK) Then
            UFScanner.GetErrorString(ufs_res, m_strError)
            tbxMessage.AppendText("UFScanner CaptureSingleImage: " & m_strError & vbNewLine)
            Exit Sub
        End If

        Select Case cbScanTemplateType.SelectedIndex

            Case 0
                Scanner.nTemplateType = 2001
            Case 1
                Scanner.nTemplateType = 2002
            Case 2
                Scanner.nTemplateType = 2003

        End Select

        ufs_res = Scanner.Extract(Template, TemplateSize, EnrollQuality)
        If (ufs_res = UFS_STATUS.OK) Then
            DrawCapturedImage(Scanner)
        Else
            UFScanner.GetErrorString(ufs_res, m_strError)
            tbxMessage.AppendText("UFScanner Extract: " & m_strError & vbNewLine)
        End If

        Select Case cbMatchTemplateType.SelectedIndex

            Case 0
                m_Matcher.nTemplateType = 2001
            Case 1
                m_Matcher.nTemplateType = 2002
            Case 2
                m_Matcher.nTemplateType = 2003

        End Select


        ufm_res = m_Matcher.Verify(Template, TemplateSize, m_template(SelectID), m_template_size(SelectID), VerifySucceed)
        If (ufs_res <> UFS_STATUS.OK) Then
            UFMatcher.GetErrorString(ufm_res, m_strError)
            tbxMessage.AppendText("UFMatcher Verify: " & m_strError & vbNewLine)
        End If

        If (VerifySucceed) Then
            tbxMessage.AppendText("Verification succeed (No." & (SelectID + 1) & ")" & vbNewLine)
        Else
            tbxMessage.AppendText("Verification failed" & vbNewLine)
        End If
    End Sub

    Private Sub btnIdentify_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim Scanner As UFScanner = Nothing
        Dim ufs_res As UFS_STATUS
        Dim ufm_res As UFM_STATUS
        Dim Template As Byte() = New Byte(MAX_TEMPLATE_SIZE) {}
        Dim TemplateSize As Integer = Nothing
        Dim EnrollQuality As Integer = Nothing
        Dim MatchIndex As Integer = Nothing

        If (GetCurrentScanner(Scanner) = False) Then
            Exit Sub
        End If
        Scanner.ClearCaptureImageBuffer()

        tbxMessage.AppendText("Place Finger" & vbNewLine)

        ufs_res = Scanner.CaptureSingleImage()
        If (ufs_res <> UFS_STATUS.OK) Then
            UFScanner.GetErrorString(ufs_res, m_strError)
            tbxMessage.AppendText("UFScanner CaptureSingleImage: " & m_strError & vbNewLine)
            Exit Sub
        End If

        Select Case cbScanTemplateType.SelectedIndex

            Case 0
                Scanner.nTemplateType = 2001
            Case 1
                Scanner.nTemplateType = 2002
            Case 2
                Scanner.nTemplateType = 2003

        End Select

        ufs_res = Scanner.Extract(Template, TemplateSize, EnrollQuality)
        If (ufs_res = UFS_STATUS.OK) Then
            DrawCapturedImage(Scanner)
        Else
            UFScanner.GetErrorString(ufs_res, m_strError)
            tbxMessage.AppendText("UFScanner Extract: " & m_strError & vbNewLine)
        End If

        Select Case cbMatchTemplateType.SelectedIndex

            Case 0
                m_Matcher.nTemplateType = 2001
            Case 1
                m_Matcher.nTemplateType = 2002
            Case 2
                m_Matcher.nTemplateType = 2003

        End Select

        Windows.Forms.Cursor.Current = Cursors.WaitCursor
        ufm_res = m_Matcher.Identify(Template, TemplateSize, m_template, m_template_size, m_template_num, 5000, MatchIndex)
        Windows.Forms.Cursor.Current = Me.Cursor
        If (ufs_res <> UFS_STATUS.OK) Then
            UFMatcher.GetErrorString(ufm_res, m_strError)
            tbxMessage.AppendText("UFMatcher Identify: " & m_strError & vbNewLine)
            Exit Sub
        End If

        If (MatchIndex <> -1) Then
            tbxMessage.AppendText("Identification succeed (No." & (MatchIndex + 1) & ")" & vbNewLine)
        Else
            tbxMessage.AppendText("Identification failed" & vbNewLine)
        End If
    End Sub

    Private Sub btnSaveTemplate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim SelectID As Integer

        SelectID = cbID.SelectedIndex
        If (SelectID = -1) Then
            tbxMessage.AppendText("Select Enroll ID" & vbCrLf)
            Exit Sub
        End If

        Dim dlg As SaveFileDialog = New SaveFileDialog()
        dlg.Filter = "Template files (*.tmp)|*.tmp"
        dlg.DefaultExt = "tmp"
        Dim res As DialogResult = dlg.ShowDialog()
        If (res <> Windows.Forms.DialogResult.OK) Then
            Exit Sub
        End If

        Dim fs As FileStream = File.Create(dlg.FileName)
        fs.Write(m_template(SelectID), 0, m_template_size(SelectID))
        fs.Close()
        tbxMessage.AppendText("Selected template is saved" & vbNewLine)
    End Sub

    Private Sub btnSaveImage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim Scanner As UFScanner = Nothing
        Dim ufs_res As UFS_STATUS

        If (GetCurrentScanner(Scanner) = False) Then
            Exit Sub
        End If

        Dim dlg As SaveFileDialog = New SaveFileDialog()
        dlg.Filter = "Bitmap files (*.bmp)|*.bmp"
        dlg.DefaultExt = "bmp"
        Dim res As DialogResult = dlg.ShowDialog()
        If (res <> Windows.Forms.DialogResult.OK) Then
            Exit Sub
        End If

        ufs_res = Scanner.SaveCaptureImageBufferToBMP(dlg.FileName)
        If (ufs_res = UFS_STATUS.OK) Then
            tbxMessage.AppendText("UFScanner Image Buffer is saved to " & dlg.FileName & vbNewLine)
        End If

    End Sub
    '==========================================================================='
End Class
