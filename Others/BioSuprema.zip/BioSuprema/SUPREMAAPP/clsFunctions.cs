using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;
namespace Suprema
{
    class clsFunctions
    {
       // public string 

        public byte[] picture(Image img)
        {
            MemoryStream ms = new MemoryStream();

          
            img.Save(ms, ImageFormat.Jpeg); 

            Byte[] pic = new Byte[ms.Length];

            ms.Position = 0;

            ms.Read(pic, 0, Convert.ToInt32(ms.Length));

            ms.Close();
            
            return pic;

		
        }

        public string TemptoString(byte[] template, int TempSize)
        { 
          String str = "";
            int i = 0;
           // string s = "";
            for (i = 0; i < TempSize; i++) 
          {
               if (i == 0)
                  {
                      str += Convert.ToString(template[i]) + ",";
                  }
                  else if (i == 1)
                  {
                      str += Convert.ToString(template[i]);
                  }
               else
                  {
                      str += "," + Convert.ToString(template[i]);
                  }
       
          }
          return str;
        }
        public byte[] StrTOTemp(String strr, out int TemSize)
        {
            byte[] arr;
            String[] strrr = strr.Split(',');
            TemSize = strrr.Length;
            arr = new byte[1024];
            int k = strr.Length;
            for (int i = 0; i < strrr.Length; i++)
            {
                if (strrr[i] != "" || strrr[i] != null)
                {
                arr[i] = Convert.ToByte(strrr[i]);
                }
            }
            return arr;
        }

        public byte[] TempCopy(byte[] template, int size)
        {
            
            byte[] Temp1 = new byte[size];
            for (int i = 0; i < size; i++)
            {
                Temp1[i] = template[i];
            }
            return Temp1;
        }
        public Boolean StringCheck(String strr)
        {
            Boolean check = true;
            String[] val = new String[15];
            val[0] = "'";
            val[1] = "~";
            val[2] = "!";
            val[3] = "%";
            val[4] = "$";
            val[5] = "#";
            val[6] = "@";
            val[7] = "`";
            val[8] = "*";
            val[9] = "(";
            val[10] = ")";
            val[11] = "-";

            val[1] = "_";
            val[2] = "=";
            val[3] = "}";
            val[4] = "{";
            val[5] = "[";
            val[6] = "]";
            val[7] = Convert.ToString('"');
            val[8] = Convert.ToString('\\');
            val[9] = "/";
            val[10] = ".";
            val[11] = ">";

            val[12] = ",";
            val[13] = "<";
            val[14] = "?";

            for (int x = 0; x < 15; x++)
            {
                if (strr.Contains(val[x]))
                {
                     check = false;
                     return check;
                    break;
                }
                else
                {
                    check = true;
                }

            }

            return check;
        }






    }
}
