using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.Odbc;
using System.Data.OleDb;
using System.Data.ProviderBase;
using System.Data.Common;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Data.OracleClient;


//using Oracle.DataAccess;
//using Oracle.DataAccess.Client;
//using Oracle.DataAccess.Types;


namespace Suprema
{
    class clsDAO
    {
        public OracleConnection con;
        public OracleDataAdapter da;
        public OracleCommand cmd;
        public OracleDataReader dr;
        public DataSet ds;
            
        public clsDAO()
        {
//            clsGlobal.Constr = "Data Source=(DESCRIPTION = (ADDRESS_LIST = (ADDRESS = (PROTOCOL = TCP)(HOST = "+clsGlobal.Host+")(PORT = "+clsGlobal.Port+")))(CONNECT_DATA = (SERVICE_NAME = "+clsGlobal.Database+")));User Id="+clsGlobal.User+";Password="+clsGlobal.Password+";";
           // clsGlobal.Constr = "Data Source=(DESCRIPTION = (ADDRESS_LIST = (ADDRESS = (PROTOCOL = TCP)(HOST = 192.168.5.27)(PORT = 1521)))(CONNECT_DATA = (SERVICE_NAME = biosuper)));User Id=system;Password=intermec;";
            clsGlobal.Constr = "Data Source=(DESCRIPTION = (ADDRESS_LIST = (ADDRESS = (PROTOCOL = TCP)(HOST = 150.151.0.4)(PORT = 1521)))(CONNECT_DATA = (SERVICE_NAME = hqdb.suparco.gov.pk)));User Id=2974;Password=727";
            con = new OracleConnection(clsGlobal.Constr);
            con.Open();
            
        }

        public DataTable SelectData (String query)
        {
         
        ds  = new DataSet();
        da = new OracleDataAdapter(query, con);

        if (con.State == ConnectionState.Closed)
        {
            con.Open();
        }
        da.Fill(ds,"TableTemp");
 
        if (ds.Tables["TableTemp"].Rows.Count >= 0) 
        {
            
            return ds.Tables["TableTemp"];
        }
        else
        {
            ds.Tables["TableTemp"].Clear();
            return ds.Tables["TableTemp"];
      
        }
        }

        public OracleDataReader SelectDataDR(String query)
        {
            cmd = new OracleCommand(query);
            

            cmd.Connection = con;

            cmd.CommandType = CommandType.Text;
            dr = cmd.ExecuteReader();
            return dr;
        }

        
        public int InsertEmpData(clsEmployee emp, string str)
        {
            da = new OracleDataAdapter() ;
            cmd = con.CreateCommand();
            String Query = "";
            String Query1 = "";
            String str2 = str;

            //OracleParameter blobParameter = new OracleParameter();
            //blobParameter.OracleType = OracleType.VarChar;
            //blobParameter.ParameterName = ":iP_NO";
            //blobParameter.Value = emp.PNo;
            //cmd.Parameters.Add(blobParameter); 
            
          cmd.Parameters.AddWithValue(":iP_NO", emp.PNo);
            
            for (int i = 0; i < str2.Length; i++)
            {
               int w = Convert.ToInt32(clsLeftRightMid.Left(str, 1));

                if (w == 0)
                {
                    if (str.Length > 1)
                    {
                        Query += "L_I_THUMB, L_T_THUMB,";
                        Query1 += ":iL_I_THUMB, :iL_T_THUMB,";

                        cmd.Parameters.AddWithValue(":iL_I_THUMB", emp.L_I_THUMB);
                        cmd.Parameters.AddWithValue(":iL_T_THUMB", emp.L_T_THUMB);
                      
                    }
                    else
                    {
                        Query += "L_I_THUMB, L_T_THUMB";
                        Query1 += ":iL_I_THUMB, :iL_T_THUMB";
                        cmd.Parameters.AddWithValue(":iL_I_THUMB", emp.L_I_THUMB);
                        cmd.Parameters.AddWithValue(":iL_T_THUMB", emp.L_T_THUMB);
                    }
                    
                }
                else if (w == 1)
                {
                    if (str.Length > 1)
                    {
                        Query += "L_I_INDEX, L_T_INDEX,";
                        Query1 += ":iL_I_INDEX, :iL_T_INDEX,";

                        cmd.Parameters.AddWithValue(":iL_I_INDEX", emp.L_I_INDEX);
                        cmd.Parameters.AddWithValue(":iL_T_INDEX", emp.L_T_INDEX);
                    }
                    else
                    {
                        Query += "L_I_INDEX, L_T_INDEX";
                        Query1 += ":iL_I_INDEX, :iL_T_INDEX";
                        cmd.Parameters.AddWithValue(":iL_I_INDEX", emp.L_I_INDEX);
                        cmd.Parameters.AddWithValue(":iL_T_INDEX", emp.L_T_INDEX);
                    }

                }
                else if (w == 2)
                {
                    if (str.Length > 1)
                    {
                        Query += "L_I_MIDDLE, L_T_MIDDLE,";
                        Query1 += ":iL_I_MIDDLE, :iL_T_MIDDLE,";

                        cmd.Parameters.AddWithValue(":iL_I_MIDDLE", emp.L_I_MIDDLE);
                        cmd.Parameters.AddWithValue(":iL_T_MIDDLE", emp.L_T_MIDDLE);

                    }
                    else
                    {
                        Query += "L_I_MIDDLE, L_T_MIDDLE";
                        Query1 += ":iL_I_MIDDLE, :iL_T_MIDDLE";

                        cmd.Parameters.AddWithValue(":iL_I_MIDDLE", emp.L_I_MIDDLE);
                        cmd.Parameters.AddWithValue(":iL_T_MIDDLE", emp.L_T_MIDDLE);

                    }
                }

                else if (w == 3)
                {
                    if (str.Length > 1)
                    {
                        Query += "L_I_RING, L_T_RING,";
                        Query1 += ":iL_I_RING, :iL_T_RING,";

                        cmd.Parameters.AddWithValue(":iL_I_RING", emp.L_I_RING);
                        cmd.Parameters.AddWithValue(":iL_T_RING", emp.L_T_RING);

                    }
                    else
                    {
                        Query += "L_I_RING, L_T_RING";
                        Query1 += ":iL_I_RING, :iL_T_RING";

                        cmd.Parameters.AddWithValue(":iL_I_RING", emp.L_I_RING);
                        cmd.Parameters.AddWithValue(":iL_T_RING", emp.L_T_RING);
                    }

                }
                else if (w == 4)
                {
                    if (str.Length > 1)
                    {
                        Query += "L_I_SMALL, L_T_SMALL,";
                        Query1 += ":iL_I_SMALL, :iL_T_SMALL,";
                        cmd.Parameters.AddWithValue(":iL_I_SMALL", emp.L_I_SMALL);
                        cmd.Parameters.AddWithValue(":iL_T_SMALL", emp.L_T_SMALL);

                    }
                    else
                    {
                        Query += "L_I_SMALL, L_T_SMALL";
                        Query1 += ":iL_I_SMALL, :iL_T_SMALL";
                        cmd.Parameters.AddWithValue(":iL_I_SMALL", emp.L_I_SMALL);
                        cmd.Parameters.AddWithValue(":iL_T_SMALL", emp.L_T_SMALL);

                    }

                }
                else if (w == 5)
                {
                    if (str.Length > 1)
                    {
                        Query += "R_I_THUMB, R_T_THUMB,";
                        Query1 += ":iR_I_THUMB, :iR_T_THUMB,";
                        cmd.Parameters.AddWithValue(":iR_I_THUMB", emp.R_I_THUMB);
                        cmd.Parameters.AddWithValue(":iR_T_THUMB", emp.R_T_THUMB);
                    }
                    else
                    {
                        Query += "R_I_THUMB, R_T_THUMB";
                        Query1 += ":iR_I_THUMB, :iR_T_THUMB";
                        cmd.Parameters.AddWithValue(":iR_I_THUMB", emp.R_I_THUMB);
                        cmd.Parameters.AddWithValue(":iR_T_THUMB", emp.R_T_THUMB);
                    }

                }
                else if (w == 6)
                {
                    if (str.Length > 1)
                    {
                        Query += "R_I_INDEX, R_T_INDEX,";
                        Query1 += ":iR_I_INDEX, :iR_T_INDEX,";
                        cmd.Parameters.AddWithValue(":iR_I_INDEX", emp.R_I_INDEX);
                        cmd.Parameters.AddWithValue(":iR_T_INDEX", emp.R_T_INDEX);

                    }
                    else
                    {
                        Query += "R_I_INDEX, R_T_INDEX";
                        Query1 += ":iR_I_INDEX, :iR_T_INDEX";
                        cmd.Parameters.AddWithValue(":iR_I_INDEX", emp.R_I_INDEX);
                        cmd.Parameters.AddWithValue(":iR_T_INDEX", emp.R_T_INDEX);

                    }

                }
                else if (w == 7)
                {
                    if (str.Length > 1)
                    {
                        Query += "R_I_MIDDLE, R_T_MIDDLE,";
                        Query1 += ":iR_I_MIDDLE, :iR_T_MIDDLE,";
                        cmd.Parameters.AddWithValue(":iR_I_MIDDLE", emp.R_I_MIDDLE);
                        cmd.Parameters.AddWithValue(":iR_T_MIDDLE", emp.R_T_MIDDLE);

                    }
                    else
                    {
                        Query += "R_I_MIDDLE, R_T_MIDDLE";
                        Query1 += ":iR_I_MIDDLE, :iR_T_MIDDLE";
                        cmd.Parameters.AddWithValue(":iR_I_MIDDLE", emp.R_I_MIDDLE);
                        cmd.Parameters.AddWithValue(":iR_T_MIDDLE", emp.R_T_MIDDLE);

                    }
                }
                else if (w == 8)
                {
                    if (str.Length > 1)
                    {
                        Query += "R_I_RING, R_T_RING,";
                        Query1 += ":iR_I_RING, :iR_T_RING,";
                        cmd.Parameters.AddWithValue(":iR_I_RING", emp.R_I_RING);
                        cmd.Parameters.AddWithValue(":iR_T_RING", emp.R_T_RING);

                    }
                    else
                    {
                        Query += "R_I_RING, R_T_RING";
                        Query1 += ":iR_I_RING, :iR_T_RING";
                        cmd.Parameters.AddWithValue(":iR_I_RING", emp.R_I_RING);
                        cmd.Parameters.AddWithValue(":iR_T_RING", emp.R_T_RING);
                    }
                }
                else if (w == 9)
                {
                    if (str.Length > 1)
                    {
                        Query += "R_I_SMALL, R_T_SMALL,";
                        Query1 += ":iR_I_SMALL, :iR_T_SMALL,";
                        cmd.Parameters.AddWithValue(":iR_I_SMALL", emp.R_I_SMALL);
                        cmd.Parameters.AddWithValue(":iR_T_SMALL", emp.R_T_SMALL);
                    }
                    else
                    {
                        Query += "R_I_SMALL, R_T_SMALL";
                        Query1 += ":iR_I_SMALL, :iR_T_SMALL";
                        cmd.Parameters.AddWithValue(":iR_I_SMALL", emp.R_I_SMALL);
                        cmd.Parameters.AddWithValue(":iR_T_SMALL", emp.R_T_SMALL);
                    }
                }
               str = clsLeftRightMid.Right(str, str.Length - 1);
           }

           cmd.Parameters.AddWithValue(":iENTRY_USER", clsGlobal.User);
           cmd.Parameters.AddWithValue(":iENTRY_DATE", DateTime.Now);

            String FQuery = "INSERT INTO HR_EMP_FINGER_IMPRESSION(P_NO," + Query + ", ENTRY_USER, ENTRY_DATE) VALUES(:iP_NO," + Query1 + ", :iENTRY_USER, :iENTRY_DATE)";
            //String FQuery = "INSERT INTO HR_EMP_FINGER_IMPRESSION (P_NO, L_I_THUMB) values (6666, :iL_I_THUMB)";
            cmd.CommandText = FQuery;
          
           int q = cmd.ExecuteNonQuery();
           
           return q;

        }



        public int UpdateEmpData(clsEmployee emp, string str)
        {
            da = new OracleDataAdapter();
            cmd = con.CreateCommand();
            String Query = "";
            //String Query1 = "";
            String str2 = str;
            cmd.Parameters.AddWithValue(":iP_NO", emp.PNo);

            for (int i = 0; i < str2.Length; i++)
            {
                int w = Convert.ToInt32(clsLeftRightMid.Left(str, 1));

                if (w == 0)
                {
                    if (str.Length > 1)
                    {
                        Query += "L_I_THUMB = :iL_I_THUMB, L_T_THUMB = :iL_T_THUMB,";
                        //Query1 += "";

                        cmd.Parameters.AddWithValue(":iL_I_THUMB", emp.L_I_THUMB);
                        cmd.Parameters.AddWithValue(":iL_T_THUMB", emp.L_T_THUMB);
                    }
                    else
                    {
                        Query += "L_I_THUMB = :iL_I_THUMB, L_T_THUMB = :iL_T_THUMB";
                        //Query1 += "";
                        cmd.Parameters.AddWithValue(":iL_I_THUMB", emp.L_I_THUMB);
                        cmd.Parameters.AddWithValue(":iL_T_THUMB", emp.L_T_THUMB);
                    }

          }
                else if (w == 1)
                {
                    if (str.Length > 1)
                    {
                        Query += "L_I_INDEX = :iL_I_INDEX, L_T_INDEX = :iL_T_INDEX,";
                       // Query1 += "";

                        cmd.Parameters.AddWithValue(":iL_I_INDEX", emp.L_I_INDEX);
                        cmd.Parameters.AddWithValue(":iL_T_INDEX", emp.L_T_INDEX);
                    }
                    else
                    {
                        Query += "L_I_INDEX = :iL_I_INDEX, L_T_INDEX = :iL_T_INDEX";
                        //Query1 += "";
                        cmd.Parameters.AddWithValue(":iL_I_INDEX", emp.L_I_INDEX);
                        cmd.Parameters.AddWithValue(":iL_T_INDEX", emp.L_T_INDEX);
                    }

                }
                else if (w == 2)
                {
                    if (str.Length > 1)
                    {
                        Query += "L_I_MIDDLE = :iL_I_MIDDLE, L_T_MIDDLE = :iL_T_MIDDLE,";
                        //Query1 += "";

                        cmd.Parameters.AddWithValue(":iL_I_MIDDLE", emp.L_I_MIDDLE);
                        cmd.Parameters.AddWithValue(":iL_T_MIDDLE", emp.L_T_MIDDLE);

                    }
                    else
                    {
                        Query += "L_I_MIDDLE = :iL_I_MIDDLE, L_T_MIDDLE = :iL_T_MIDDLE";
                       // Query1 += "";

                        cmd.Parameters.AddWithValue(":iL_I_MIDDLE", emp.L_I_MIDDLE);
                        cmd.Parameters.AddWithValue(":iL_T_MIDDLE", emp.L_T_MIDDLE);

                    }
                }

                else if (w == 3)
                {
                    if (str.Length > 1)
                    {
                        Query += "L_I_RING = :iL_I_RING, L_T_RING = :iL_T_RING,";
                        //Query1 += "";

                        cmd.Parameters.AddWithValue(":iL_I_RING", emp.L_I_RING);
                        cmd.Parameters.AddWithValue(":iL_T_RING", emp.L_T_RING);

                    }
                    else
                    {
                        Query += "L_I_RING = :iL_I_RING, L_T_RING = :iL_T_RING";
                        //Query1 += "";

                        cmd.Parameters.AddWithValue(":iL_I_RING", emp.L_I_RING);
                        cmd.Parameters.AddWithValue(":iL_T_RING", emp.L_T_RING);
                    }

                }
                else if (w == 4)
                {
                    if (str.Length > 1)
                    {
                        Query += "L_I_SMALL = :iL_I_SMALL, L_T_SMALL = :iL_T_SMALL,";
                        //Query1 += "";
                        cmd.Parameters.AddWithValue(":iL_I_SMALL", emp.L_I_SMALL);
                        cmd.Parameters.AddWithValue(":iL_T_SMALL", emp.L_T_SMALL);

                    }
                    else
                    {
                        Query += "L_I_SMALL = :iL_I_SMALL, L_T_SMALL = :iL_T_SMALL";
                        //Query1 += "";
                        cmd.Parameters.AddWithValue(":iL_I_SMALL", emp.L_I_SMALL);
                        cmd.Parameters.AddWithValue(":iL_T_SMALL", emp.L_T_SMALL);

                    }

                }
                else if (w == 5)
                {
                    if (str.Length > 1)
                    {
                        Query += "R_I_THUMB = :iR_I_THUMB, R_T_THUMB = :iR_T_THUMB,";
                        //Query1 += "";
                        cmd.Parameters.AddWithValue(":iR_I_THUMB", emp.R_I_THUMB);
                        cmd.Parameters.AddWithValue(":iR_T_THUMB", emp.R_T_THUMB);
                    }
                    else
                    {
                        Query += "R_I_THUMB = :iR_I_THUMB, R_T_THUMB = :iR_T_THUMB";
                        //Query1 += "";
                        cmd.Parameters.AddWithValue(":iR_I_THUMB", emp.R_I_THUMB);
                        cmd.Parameters.AddWithValue(":iR_T_THUMB", emp.R_T_THUMB);
                    }

                }
                else if (w == 6)
                {
                    if (str.Length > 1)
                    {
                        Query += "R_I_INDEX = :iR_I_INDEX, R_T_INDEX = :iR_T_INDEX,";
                       // Query1 += "";
                        cmd.Parameters.AddWithValue(":iR_I_INDEX", emp.R_I_INDEX);
                        cmd.Parameters.AddWithValue(":iR_T_INDEX", emp.R_T_INDEX);

                    }
                    else
                    {
                        Query += "R_I_INDEX = :iR_I_INDEX, R_T_INDEX = :iR_T_INDEX";
                        //Query1 += "R_T_INDEX = :iR_T_INDEX";
                        cmd.Parameters.AddWithValue(":iR_I_INDEX", emp.R_I_INDEX);
                        cmd.Parameters.AddWithValue(":iR_T_INDEX", emp.R_T_INDEX);

                    }

                }
                else if (w == 7)
                {
                    if (str.Length > 1)
                    {
                        Query += "R_I_MIDDLE = :iR_I_MIDDLE, R_T_MIDDLE = :iR_T_MIDDLE,";
                        //Query1 += "";
                        cmd.Parameters.AddWithValue(":iR_I_MIDDLE", emp.R_I_MIDDLE);
                        cmd.Parameters.AddWithValue(":iR_T_MIDDLE", emp.R_T_MIDDLE);

                    }
                    else
                    {
                        Query += "R_I_MIDDLE = :iR_I_MIDDLE, R_T_MIDDLE = :iR_T_MIDDLE";
                        //Query1 += "R_T_MIDDLE = :iR_T_MIDDLE";
                        cmd.Parameters.AddWithValue(":iR_I_MIDDLE", emp.R_I_MIDDLE);
                        cmd.Parameters.AddWithValue(":iR_T_MIDDLE", emp.R_T_MIDDLE);

                    }
                }
                else if (w == 8)
                {
                    if (str.Length > 1)
                    {
                        Query += "R_I_RING = :iR_I_RING, R_T_RING = :iR_T_RING,";
                        //Query1 += "";
                        cmd.Parameters.AddWithValue(":iR_I_RING", emp.R_I_RING);
                        cmd.Parameters.AddWithValue(":iR_T_RING", emp.R_T_RING);

                    }
                    else
                    {
                        Query += "R_I_RING = :iR_I_RING, R_T_RING = :iR_T_RING";
                        //Query1 += "R_T_RING = :iR_T_RING,";
                        cmd.Parameters.AddWithValue(":iR_I_RING", emp.R_I_RING);
                        cmd.Parameters.AddWithValue(":iR_T_RING", emp.R_T_RING);
                    }
                }
                else if (w == 9)
                {
                    if (str.Length > 1)
                    {
                        Query += "R_I_SMALL = :iR_I_SMALL, R_T_SMALL = :iR_T_SMALL,";
                       // Query1 += "";
                        cmd.Parameters.AddWithValue(":iR_I_SMALL", emp.R_I_SMALL);
                        cmd.Parameters.AddWithValue(":iR_T_SMALL", emp.R_T_SMALL);
                    }
                    else
                    {
                        Query += "R_I_SMALL = :iR_I_SMALL, R_T_SMALL = :iR_T_SMALL";
                        //Query1 += "";
                        cmd.Parameters.AddWithValue(":iR_I_SMALL", emp.R_I_SMALL);
                        cmd.Parameters.AddWithValue(":iR_T_SMALL", emp.R_T_SMALL);
                    }
                }
                str = clsLeftRightMid.Right(str, str.Length - 1);
            }
            //"UPDATE emp SET job = :iJOB, photo = :iPHOTO WHERE empno = :iEMPNO";

            cmd.Parameters.AddWithValue(":iENTRY_USER", clsGlobal.User);
            cmd.Parameters.AddWithValue(":iENTRY_DATE", DateTime.Now);

            String FQuery = "UPDATE HR_EMP_FINGER_IMPRESSION SET " + Query + ", ENTRY_USER = :iENTRY_USER, ENTRY_DATE = :iENTRY_DATE   WHERE P_NO = :iP_NO";
            cmd.CommandText = FQuery;
            //cmd.CommandText = "INSERT INTO HR_EMP_FINGER_IMPRESSION(P_NO, R_I_THUMB, R_T_THUMB) VALUES(:iP_NO, :iR_I_THUMB, :iR_T_THUMB)";
            //cmd.Parameters.Add(":iP_NO", OracleDbType.Varchar2, 20, emp.PNo, ParameterDirection.Input);
            //cmd.Parameters.Add(":iR_I_THUMB", OracleDbType.Blob, ByteToBlob(emp.R_I_THUMB), ParameterDirection.Input);
            //cmd.Parameters.Add(":iR_T_THUMB", OracleDbType.Varchar2, 200, emp.R_T_THUMB, ParameterDirection.Input);

            int q = cmd.ExecuteNonQuery();

            return q;

        }
        
        public OracleLob ByteToBlob(Byte []att)
        {
            OracleLob blb = null;
            blb.Write(att, 0, att.Length);
            return blb;
        }

        public byte[] BlobToByte(OracleLob blb)
        {
            Byte[] att = new Byte[blb.Length];
            int i = blb.Read(att, 0, System.Convert.ToInt32(blb.Length));
            return att;
        }



        //grpLIndex.BringToFront();

        //            OracleBlob blob = DAO.dr.GetOracleBlob(5); 

        //            // Create a byte array of the size of the Blob obtained
        //            Byte[] byteArr = new Byte[blob.Length];

        //            // Read blob data into byte array
        //            int i = blob.Read(byteArr, 0, System.Convert.ToInt32(blob.Length));

        //            // Get the primitive byte data into in-memory data stream
        //            MemoryStream memStream = new MemoryStream(byteArr);

        //            // Attach the in-memory data stream to the PictureBox
        //            pbLeftIndex.Image = Image.FromStream(memStream);

        //            // Fit the image to the PictureBox size
        //           pbLeftIndex.SizeMode = PictureBoxSizeMode.StretchImage;
        
    }

    
    
}
