using System;
using System.Collections.Generic;
using System.Text;
using System.Data.OracleClient;

namespace Suprema
{
    class clsEmployee
    {
        public string PNo;
        public String EmpName;
        public String Designation;
        public String Place;
        
        //public Oracle.DataAccess.Types.OracleBlob L_I_THUMB;
        //public Oracle.DataAccess.Types.OracleBlob L_I_INDEX;
        //public Oracle.DataAccess.Types.OracleBlob L_I_MIDDLE;
        //public Oracle.DataAccess.Types.OracleBlob L_I_RING;
        //public Oracle.DataAccess.Types.OracleBlob L_I_SMALL;
        //public Oracle.DataAccess.Types.OracleBlob R_I_THUMB;
        //public Oracle.DataAccess.Types.OracleBlob R_I_INDEX;
        //public Oracle.DataAccess.Types.OracleBlob R_I_MIDDLE;
        //public Oracle.DataAccess.Types.OracleBlob R_I_RING;
        //public Oracle.DataAccess.Types.OracleBlob R_I_SMALL;

        public byte[] L_I_THUMB;
        public byte[] L_I_INDEX;
        public byte[] L_I_MIDDLE;
        public byte[] L_I_RING;
        public byte[] L_I_SMALL;
        public byte[] R_I_THUMB;
        public byte[] R_I_INDEX;
        public byte[] R_I_MIDDLE;
        public byte[] R_I_RING;
        public byte[] R_I_SMALL;

        
        public OracleString L_T_THUMB;
        public OracleString L_T_INDEX;
        public OracleString L_T_MIDDLE;
        public OracleString L_T_RING;
        public OracleString L_T_SMALL;
        public OracleString R_T_THUMB;
        public OracleString R_T_INDEX;
        public OracleString R_T_MIDDLE;
        public OracleString R_T_RING;
        public OracleString R_T_SMALL;

  
       public  void clears()
        { 
         PNo = null;
         EmpName = null;
         Designation = null;
         Place = null;
        L_I_THUMB = null;
        L_I_INDEX = null;
        L_I_MIDDLE = null;
        L_I_RING = null;
        L_I_SMALL = null;
        R_I_THUMB = null;
        R_I_INDEX = null;
        R_I_MIDDLE = null;
        R_I_RING = null;
        R_I_SMALL = null;
        L_T_THUMB = null;
        L_T_INDEX = null;
        L_T_MIDDLE = null;
        L_T_RING = null;
        L_T_SMALL = null;
        R_T_THUMB = null;
        R_T_INDEX = null;
        R_T_MIDDLE = null;
        R_T_RING = null;
        R_T_SMALL = null;


        }

        //public Boolean L_CHECK_THUMB;
        //public Boolean L_CHECK_INDEX;
        //public Boolean L_CHECK_MIDDLE;
        //public Boolean L_CHECK_RING;
        //public Boolean L_CHECK_SMALL;
        //public Boolean R_CHECK_THUMB;
        //public Boolean R_CHECK_INDEX;
        //public Boolean R_CHECK_MIDDLE;
        //public Boolean R_CHECK_RING;
        //public Boolean R_CHECK_SMALL;

        //clsEmployee()
        //{ 
        //PNo = 0;
        //EmpName = "";
        //Designation = "";
        //Place = "";
        
        //L_I_THUMB = ;
        //public Oracle.DataAccess.Types.OracleBlob L_I_INDEX;
        //public Oracle.DataAccess.Types.OracleBlob L_I_MIDDLE;
        //public Oracle.DataAccess.Types.OracleBlob L_I_RING;
        //public Oracle.DataAccess.Types.OracleBlob L_I_SMALL;
        //public Oracle.DataAccess.Types.OracleBlob R_I_THUMB;
        //public Oracle.DataAccess.Types.OracleBlob R_I_INDEX;
        //public Oracle.DataAccess.Types.OracleBlob R_I_MIDDLE;
        //public Oracle.DataAccess.Types.OracleBlob R_I_RING;
        //public Oracle.DataAccess.Types.OracleBlob R_I_SMALL;

        //public Oracle.DataAccess.Types.OracleString L_T_THUMB;
        //public Oracle.DataAccess.Types.OracleString L_T_INDEX;
        //public Oracle.DataAccess.Types.OracleString L_T_MIDDLE;
        //public Oracle.DataAccess.Types.OracleString L_T_RING;
        //public Oracle.DataAccess.Types.OracleString L_T_SMALL;
        //public Oracle.DataAccess.Types.OracleString R_T_THUMB;
        //public Oracle.DataAccess.Types.OracleString R_T_INDEX;
        //public Oracle.DataAccess.Types.OracleString R_T_MIDDLE;
        //public Oracle.DataAccess.Types.OracleString R_T_RING;
        //public Oracle.DataAccess.Types.OracleString R_T_SMALL;
        //}
    }

}
