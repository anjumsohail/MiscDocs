using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Suprema;

namespace SUPREMAAPP
{
    public partial class frmReports : Form
    {
        String SQLEMP = "";
        Boolean fLoad = false;
        int tabcheck = 0;
        public frmReports()
        {
            InitializeComponent();
        }

        private void frmReports_Load(object sender, EventArgs e)
        {
            //LoadEmps();
            cboLoad();
            fLoad = true;
        }
        private void cboLoad()
        {
            clsDAO DAO = new clsDAO();
            DataTable dtDiv = DAO.SelectData("Select Distinct Place from Division");

            DataTable dtDes = DAO.SelectData("Select Distinct DESIG from PERS_REC1");
            DataTable dtEmp = DAO.SelectData("SELECT a.P_NO, a.NAME, a.DESIG, b.PLACE FROM PERS_REC1 a LEFT OUTER JOIN DIVISION b ON a.BR_CODE = b.CODE Order by a.P_NO");

            if (dtDiv.Rows.Count > 0)
            {
                cboDiv.Enabled = true;
                cboDiv.Items.Add("All");
                for (int x = 0; x < dtDiv.Rows.Count; x++)
                {
                    cboDiv.Items.Add(dtDiv.Rows[x].ItemArray.GetValue(0));
                }
                cboDiv.SelectedIndex = 0;
            }
            else
            {
                cboDiv.Enabled = false;
                cboDiv.Items.Clear();
            }

            if (dtDes.Rows.Count > 0)
            {
                cboDesig.Enabled = true;
                cboDesig.Items.Add("All");

                for (int x = 0; x < dtDes.Rows.Count; x++)
                {
                    cboDesig.Items.Add(dtDes.Rows[x].ItemArray.GetValue(0));
                }
                cboDesig.SelectedIndex = 0;
            }
            else
            {
                cboDesig.Enabled = false;
                cboDesig.Items.Clear();
            }

            if (dtEmp.Rows.Count != 0)
            {
                for (int i = 0; i < dtEmp.Rows.Count; i++)
                {
                    lstEmp.Items.Add(dtEmp.Rows[i].ItemArray.GetValue(0).ToString());
                    lstEmp.Items[i].SubItems.Add(dtEmp.Rows[i].ItemArray.GetValue(1).ToString());
                    lstEmp.Items[i].SubItems.Add(dtEmp.Rows[i].ItemArray.GetValue(2).ToString());
                    lstEmp.Items[i].SubItems.Add(dtEmp.Rows[i].ItemArray.GetValue(3).ToString());

                }
            }
            
            DataTable dtEnUser = DAO.SelectData("Select Distinct ENTRY_USER from HR_EMP_FINGER_IMPRESSION where ENTRY_USER is not NULL");
            if (dtEnUser.Rows.Count > 0)
            {
                cboEnUser.Enabled = true;
                cboEnUser.Items.Add("All");
                for (int x = 0; x < dtEnUser.Rows.Count; x++)
                {
                    cboEnUser.Items.Add(dtEnUser.Rows[x].ItemArray.GetValue(0));
                }
                cboEnUser.SelectedIndex = 0;
            }
            else
            {
                cboEnUser.Enabled = false;
                cboEnUser.Items.Clear();
            }

        }
         private void LoadEmps()
         {
             String str;

            clsDAO DAO = new clsDAO();

            str = "SELECT HR_EMP_FINGER_IMPRESSION.P_NO, PERS_REC1.NAME, PERS_REC1.DESIG,  DIVISION.PLACE   FROM DIVISION, HR_EMP_FINGER_IMPRESSION,     PERS_REC1     WHERE ( ( PERS_REC1.BR_CODE = DIVISION.CODE    )     AND ( PERS_REC1.P_NO =     HR_EMP_FINGER_IMPRESSION.P_NO ) )Order by HR_EMP_FINGER_IMPRESSION.P_NO";
   DataTable dt = DAO.SelectData(str);

   if (dt.Rows.Count != 0)
   { 
    for(int i = 0; i < dt.Rows.Count; i++)
    {
        lstEmp.Items.Add(dt.Rows[i].ItemArray.GetValue(0).ToString());
        lstEmp.Items[i].SubItems.Add(dt.Rows[i].ItemArray.GetValue(1).ToString());
        lstEmp.Items[i].SubItems.Add(dt.Rows[i].ItemArray.GetValue(2).ToString());
        lstEmp.Items[i].SubItems.Add(dt.Rows[i].ItemArray.GetValue(3).ToString());

    }
    }
        //If strcount <> 0 Then
        //    str = "SELECT HRTEmployeeDetail.EmployeeNo, HRTEmployee.EmployeeName, HRTCompanyLogicDetail.Description FROM HRTCompanyLogicDetail INNER JOIN HRTCompanyLogic ON HRTCompanyLogicDetail.TypeCode = HRTCompanyLogic.TypeCode INNER JOIN HRTEmployeeDetail INNER JOIN HRTEmployee ON HRTEmployeeDetail.EmployeeNo = HRTEmployee.EmployeeNo ON HRTCompanyLogicDetail.CompanyLogicID = HRTEmployeeDetail.CompanyLogicID WHERE (HRTCompanyLogic.TypeName = 'Department') and (HRTEmployee.Active = '1') Order by HRTEmployeeDetail.EmployeeNo"
        //    da = New SqlDataAdapter(str, conn.cn)
        //    ds = New DataSet
        //    da.Fill(ds, "HRTEmployee")

        //    For x As Integer = 0 To strcount - 1
        //        Me.lvwEmp.Items.Add(ds.Tables(0).Rows.Item(x).ItemArray.GetValue(0))
        //        Me.lvwEmp.Items(x).SubItems.Add(ds.Tables(0).Rows.Item(x).ItemArray.GetValue(1))
        //        Me.lvwEmp.Items(x).SubItems.Add(ds.Tables(0).Rows.Item(x).ItemArray.GetValue(2))
        //    Next
        //End If
        }

        private void EmpSelection()
        {
            SQLEMP = "";
            if (lstEmp.CheckedItems.Count >1)
            {
                for (int i = 0; i < lstEmp.CheckedItems.Count; i++)
                {
                    if (i != lstEmp.CheckedItems.Count-1)
                    {
                        SQLEMP += "PERS_REC1.P_NO =" + this.lstEmp.CheckedItems[i].Text + " OR ";
                       // PERS_REC1.P_NO = "";
                    }
                    else 
                    {
                        SQLEMP += "PERS_REC1.P_NO =" + this.lstEmp.CheckedItems[i].Text;
                        //PERS_REC1.P_NO = "";
                    }
                 }
            }
            else if (lstEmp.CheckedItems.Count == 1)
            {
                SQLEMP += "PERS_REC1.P_NO =" + this.lstEmp.CheckedItems[0].Text;
      
            }
        
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CrystalDecisions.Shared.TableLogOnInfo TableInfo = new CrystalDecisions.Shared.TableLogOnInfo();
            CrystalDecisions.Shared.TableLogOnInfos TableInfos = new CrystalDecisions.Shared.TableLogOnInfos();
            CrystalDecisions.Shared.ConnectionInfo ConInfo = new CrystalDecisions.Shared.ConnectionInfo();
            
            
 
            if (tabcheck == 0)
            {
                if (lstEmp.CheckedItems.Count > 0)
                {

                    
                    EmpSelection();
                    string sql = "SELECT DIVISION.PLACE, HR_EMP_FINGER_IMPRESSION.ENTRY_DATE, HR_EMP_FINGER_IMPRESSION.ENTRY_USER, HR_EMP_FINGER_IMPRESSION.L_I_INDEX, HR_EMP_FINGER_IMPRESSION.L_I_MIDDLE, HR_EMP_FINGER_IMPRESSION.L_I_RING, HR_EMP_FINGER_IMPRESSION.L_I_SMALL, HR_EMP_FINGER_IMPRESSION.L_I_THUMB, HR_EMP_FINGER_IMPRESSION.L_T_INDEX, HR_EMP_FINGER_IMPRESSION.L_T_MIDDLE, HR_EMP_FINGER_IMPRESSION.L_T_RING, HR_EMP_FINGER_IMPRESSION.L_T_SMALL, HR_EMP_FINGER_IMPRESSION.L_T_THUMB, HR_EMP_FINGER_IMPRESSION.R_I_INDEX, HR_EMP_FINGER_IMPRESSION.R_I_MIDDLE, HR_EMP_FINGER_IMPRESSION.R_I_RING, HR_EMP_FINGER_IMPRESSION.R_I_SMALL, HR_EMP_FINGER_IMPRESSION.R_I_THUMB, HR_EMP_FINGER_IMPRESSION.R_T_INDEX, HR_EMP_FINGER_IMPRESSION.R_T_MIDDLE, HR_EMP_FINGER_IMPRESSION.R_T_RING, HR_EMP_FINGER_IMPRESSION.R_T_SMALL, HR_EMP_FINGER_IMPRESSION.R_T_THUMB, PERS_REC1.DESIG, PERS_REC1.NAME, PERS_REC1.P_NO FROM DIVISION, HR_EMP_FINGER_IMPRESSION, PERS_REC1 WHERE ( ( PERS_REC1.BR_CODE = DIVISION.CODE ) AND ( PERS_REC1.P_NO = HR_EMP_FINGER_IMPRESSION.P_NO ) ) And (" + SQLEMP + ") Order by PERS_REC1.P_NO";
                    clsDAO DAO = new clsDAO();
                    DataTable dt = DAO.SelectData(sql);
                    if (dt.Rows.Count > 0)
                    {
                        button1.Enabled = false;

                        CR_IndReport ri = new CR_IndReport();
                        ri.SetDatabaseLogon("system", "intermec","192.168.5.27", "biosuper");


                        ri.SetDataSource(dt);

                        frmReportsShow frs = new frmReportsShow();
                        frs.MdiParent = this.ParentForm;
                        frs.Show();

                        frs.crystalReportViewer1.ReportSource = ri;

                        frs.crystalReportViewer1.RefreshReport();
                        frs.Show();
                        button1.Enabled = true;
                    }
                    else
                    {
                        MessageBox.Show("No Records Found...!");
                    }


                }
                else
                {
                    MessageBox.Show("Please Select any Employee...!!");
                }

               

            }

            else 
                if(tabcheck == 1 )
                {

   


                      //  EmpSelection();
                        String SelCriteria = LogSelection();
                        if (SelCriteria != "a")
                        {
                            
                            string sql = "SELECT a.P_NO, b.NAME,a.ENTRY_USER,a.ENTRY_DATE FROM HR_EMP_FINGER_IMPRESSION a INNER JOIN PERS_REC1 b ON a.P_NO= b.P_NO  " + SelCriteria;
                            clsDAO DAO = new clsDAO();
                            DataTable dt = DAO.SelectData(sql);
                            if (dt.Rows.Count > 0)
                            {
                                button1.Enabled = false;

                                //CR_IndReport rp2 = new CR_IndReport();
                                CR_LogReport rp1 = new CR_LogReport();
                                //rp2.SetDatabaseLogon("system", "intermec", "192.168.5.27", "biosuper");
                                rp1.SetDatabaseLogon("system","intermec","192.168.5.27","biosuper");
                                //rp1.OpenSubreport("CR_IndReport.rpt").DataSourceConnections[0].SetConnection("192.168.5.27","biosuper","system", "intermec");

                                
                                rp1.SetDataSource(dt);

                                frmReportsShow frs = new frmReportsShow();
                                frs.MdiParent = this.ParentForm;
                                frs.Show();

                                frs.crystalReportViewer1.ReportSource = rp1;

                                frs.crystalReportViewer1.RefreshReport();
                                frs.Show();
                                button1.Enabled = true;
                            }
                            else
                            {
                                MessageBox.Show("No Records Found...!");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Use Any Searching Criteria");

                        }
                    
                    


                }

        }
        private string LogSelection()
        {
            if (chk_entusr.Checked == true && chk_entdate.Checked == false)
            {
                if(this.cboEnUser.Text == "All")
                {
                return "";
  
                }
                else
                {
                return " WHERE a.ENTRY_USER ='" + this.cboEnUser.Text + "'";
                }
            }
            else if (chk_entusr.Checked == false && chk_entdate.Checked == true)
            {
                return "where a.ENTRY_DATE ='" + this.dtp_endate.Text + "'"; 
            }
            else if (chk_entusr.Checked == true && chk_entdate.Checked == true)
            {
                if (this.cboEnUser.Text == "All")
                {
                    return "where a.ENTRY_DATE ='" + this.dtp_endate.Text + "'";

                }
                else
                {
                    return "where a.ENTRY_USER ='" + this.cboEnUser.Text + "' AND a.ENTRY_DATE ='" + this.dtp_endate.Text + "'";
                }
                
            }
            else
            {
                return "a";
            }
        
        }
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void cboDiv_SelectedIndexChanged(object sender, EventArgs e)
        {
            Selection();
        }

        private void cboDesig_SelectedIndexChanged(object sender, EventArgs e)
        {
            Selection();
        }

        private void Selection()
        {
            if (fLoad == true)
            {
                if (cboDiv.Text == "All" && cboDesig.Text == "All")
                {
                    clsDAO DAO = new clsDAO();
                    lstEmp.Items.Clear();
                    DataTable dtEmp = DAO.SelectData("SELECT PERS_REC1.P_NO, PERS_REC1.NAME, PERS_REC1.DESIG, DIVISION.PLACE FROM PERS_REC1,  DIVISION WHERE  PERS_REC1.BR_CODE = DIVISION.CODE Order by PERS_REC1.P_NO");
                    if (dtEmp.Rows.Count != 0)
                    {
                        //this.btnSave.Enabled = true;
                        for (int i = 0; i < dtEmp.Rows.Count; i++)
                        {
                            lstEmp.Items.Add(dtEmp.Rows[i].ItemArray.GetValue(0).ToString());
                            lstEmp.Items[i].SubItems.Add(dtEmp.Rows[i].ItemArray.GetValue(1).ToString());
                            lstEmp.Items[i].SubItems.Add(dtEmp.Rows[i].ItemArray.GetValue(2).ToString());
                            lstEmp.Items[i].SubItems.Add(dtEmp.Rows[i].ItemArray.GetValue(3).ToString());

                        }
                    }
                    else
                    {
                        //this.btnSave.Enabled = false;

                    }
                }
                else if (cboDiv.Text != "All" && cboDesig.Text == "All")
                {
                    clsDAO DAO = new clsDAO();
                    lstEmp.Items.Clear();
                    DataTable dtEmp = DAO.SelectData("SELECT PERS_REC1.P_NO, PERS_REC1.NAME, PERS_REC1.DESIG, DIVISION.PLACE FROM PERS_REC1,  DIVISION WHERE  PERS_REC1.BR_CODE = DIVISION.CODE And DIVISION.PLACE ='" + cboDiv.Text + "' Order by PERS_REC1.P_NO");
                    if (dtEmp.Rows.Count != 0)
                    {
                       // this.btnSave.Enabled = true;
                        for (int i = 0; i < dtEmp.Rows.Count; i++)
                        {
                            lstEmp.Items.Add(dtEmp.Rows[i].ItemArray.GetValue(0).ToString());
                            lstEmp.Items[i].SubItems.Add(dtEmp.Rows[i].ItemArray.GetValue(1).ToString());
                            lstEmp.Items[i].SubItems.Add(dtEmp.Rows[i].ItemArray.GetValue(2).ToString());
                            lstEmp.Items[i].SubItems.Add(dtEmp.Rows[i].ItemArray.GetValue(3).ToString());

                        }
                    }
                    else
                    {
                        //this.btnSave.Enabled = false;
                    }
                }
                else if (cboDiv.Text == "All" && cboDesig.Text != "All")
                {
                    clsDAO DAO = new clsDAO();
                    lstEmp.Items.Clear();
                    DataTable dtEmp = DAO.SelectData("SELECT PERS_REC1.P_NO, PERS_REC1.NAME, PERS_REC1.DESIG, DIVISION.PLACE FROM PERS_REC1,  DIVISION WHERE  PERS_REC1.BR_CODE = DIVISION.CODE And PERS_REC1.DESIG ='" + cboDesig.Text + "'");
                    if (dtEmp.Rows.Count != 0)
                    {
                        //this.btnSave.Enabled = true;
                        for (int i = 0; i < dtEmp.Rows.Count; i++)
                        {
                            lstEmp.Items.Add(dtEmp.Rows[i].ItemArray.GetValue(0).ToString());
                            lstEmp.Items[i].SubItems.Add(dtEmp.Rows[i].ItemArray.GetValue(1).ToString());
                            lstEmp.Items[i].SubItems.Add(dtEmp.Rows[i].ItemArray.GetValue(2).ToString());
                            lstEmp.Items[i].SubItems.Add(dtEmp.Rows[i].ItemArray.GetValue(3).ToString());

                        }
                    }
                    else
                    {
                       // this.btnSave.Enabled = false;
                    }
                }
                else if (cboDiv.Text != "All" && cboDesig.Text != "All")
                {
                    clsDAO DAO = new clsDAO();
                    lstEmp.Items.Clear();
                    DataTable dtEmp = DAO.SelectData("SELECT PERS_REC1.P_NO, PERS_REC1.NAME, PERS_REC1.DESIG, DIVISION.PLACE FROM PERS_REC1,  DIVISION WHERE  PERS_REC1.BR_CODE = DIVISION.CODE And PERS_REC1.DESIG ='" + cboDesig.Text + "' And DIVISION.PLACE ='" + cboDiv.Text + "' Order by PERS_REC1.P_NO");
                    if (dtEmp.Rows.Count != 0)
                    {
                 //       this.btnSave.Enabled = true;
                        for (int i = 0; i < dtEmp.Rows.Count; i++)
                        {
                            lstEmp.Items.Add(dtEmp.Rows[i].ItemArray.GetValue(0).ToString());
                            lstEmp.Items[i].SubItems.Add(dtEmp.Rows[i].ItemArray.GetValue(1).ToString());
                            lstEmp.Items[i].SubItems.Add(dtEmp.Rows[i].ItemArray.GetValue(2).ToString());
                            lstEmp.Items[i].SubItems.Add(dtEmp.Rows[i].ItemArray.GetValue(3).ToString());

                        }
                    }
                    else
                    {
                  //      this.btnSave.Enabled = false;
                    }
                }

            }
        }

        private void rbInd_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void txtPNO_TextChanged(object sender, EventArgs e)
        {

        }

        private void lstEmp_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void cboDiv_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        /*private void button4_Click(object sender, EventArgs e)
        {
         
            if (radioButton1.Checked)
            {
                string connectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\\HasanJamalFiles\\EmployeeList.mdb;Persist Security Info=False";
               OleDbConnection conn = new OleDbConnection(connectionString);
               conn.Open();
               
               string commandString = "select ListId from MailingList where UpdateUser= '" + this.comboBox1.Text + "'";
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString,conn);
                ds = new DataSet();
                dataAdapter.Fill(ds,"MailingList");
                this.dataGridView1.DataSource = ds.Tables[0];
            }
            
            else
                if (radioButton2.Checked)
                {
                    string connectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\\HasanJamalFiles\\EmployeeList.mdb;Persist Security Info=False";
                    OleDbConnection conn = new OleDbConnection(connectionString);
                    conn.Open();
                    string commandString = "select ListId from MailingList where UpdateDate= #" + this.dateTimePicker1.Text + "#";
                    OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);
                    ds = new DataSet();
                    dataAdapter.Fill(ds,"MailingList");
                    this.dataGridView1.DataSource = ds.Tables[0];  
                }
        
        } */

        private void cboDesig_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void cboEnUser_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
        Pageverification();
        }
         private void Pageverification()
        {
            if (tabPage1.Focus())
            { tabcheck = 0; }
            else if (tabPage2.Focus())
            { tabcheck = 1; }
        }

        private void tabControl1_TabIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void cboEnUser_SelectedIndexChanged_1(object sender, EventArgs e)
        {
        
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void btnClose_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

            
    }

}
