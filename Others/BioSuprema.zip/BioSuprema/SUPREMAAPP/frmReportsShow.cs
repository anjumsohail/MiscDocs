using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Suprema
{
    public partial class frmReportsShow : Form
    {
        public frmReportsShow()
        {
            InitializeComponent();
        }

        private void frmReportsShow_Load(object sender, EventArgs e)
        {
            
        }
    }
}