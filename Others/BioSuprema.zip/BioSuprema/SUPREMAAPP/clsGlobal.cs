using System;
using System.Collections.Generic;
using System.Text;

namespace Suprema
{
    static class clsGlobal
    {
        static public String User;
        static public String Password;
        
        static public String Constr;
        static public String Host;
        static public String Port;
        static public String Database;

        static public Boolean Authentication;
        static public Boolean state;
        //public String User;
        //static public String Password;

        static public String PNOstr;
    }
}
