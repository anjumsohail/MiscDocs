namespace SUPREMAAPP
{
    partial class frmReports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmReports));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label2 = new System.Windows.Forms.Label();
            this.txtPNO = new System.Windows.Forms.TextBox();
            this.SelectionCriteria = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cboDesig = new System.Windows.Forms.ComboBox();
            this.cboDiv = new System.Windows.Forms.ComboBox();
            this.rbInd = new System.Windows.Forms.RadioButton();
            this.lstEmp = new System.Windows.Forms.ListView();
            this.P_No = new System.Windows.Forms.ColumnHeader();
            this.EMPName = new System.Windows.Forms.ColumnHeader();
            this.Designation = new System.Windows.Forms.ColumnHeader();
            this.Division = new System.Windows.Forms.ColumnHeader();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.chk_entdate = new System.Windows.Forms.CheckBox();
            this.chk_entusr = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.dtp_endate = new System.Windows.Forms.DateTimePicker();
            this.cboEnUser = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.SelectionCriteria.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(512, 48);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 26);
            this.label1.TabIndex = 3;
            this.label1.Text = "Reports";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(0, 54);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(500, 387);
            this.tabControl1.TabIndex = 4;
            this.tabControl1.TabIndexChanged += new System.EventHandler(this.tabControl1_TabIndexChanged);
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.txtPNO);
            this.tabPage1.Controls.Add(this.SelectionCriteria);
            this.tabPage1.Controls.Add(this.rbInd);
            this.tabPage1.Controls.Add(this.lstEmp);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(492, 361);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Individual Report";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(22, 83);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 15);
            this.label2.TabIndex = 21;
            this.label2.Text = "PNO.";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtPNO
            // 
            this.txtPNO.Location = new System.Drawing.Point(86, 82);
            this.txtPNO.Name = "txtPNO";
            this.txtPNO.Size = new System.Drawing.Size(121, 20);
            this.txtPNO.TabIndex = 20;
            // 
            // SelectionCriteria
            // 
            this.SelectionCriteria.Controls.Add(this.label4);
            this.SelectionCriteria.Controls.Add(this.label5);
            this.SelectionCriteria.Controls.Add(this.cboDesig);
            this.SelectionCriteria.Controls.Add(this.cboDiv);
            this.SelectionCriteria.Location = new System.Drawing.Point(7, 37);
            this.SelectionCriteria.Name = "SelectionCriteria";
            this.SelectionCriteria.Size = new System.Drawing.Size(444, 43);
            this.SelectionCriteria.TabIndex = 19;
            this.SelectionCriteria.TabStop = false;
            this.SelectionCriteria.Text = "SelectionCriteria";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(219, 19);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 15);
            this.label4.TabIndex = 10;
            this.label4.Text = "Designation";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(15, 19);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 15);
            this.label5.TabIndex = 9;
            this.label5.Text = "Division";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cboDesig
            // 
            this.cboDesig.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboDesig.FormattingEnabled = true;
            this.cboDesig.Location = new System.Drawing.Point(303, 16);
            this.cboDesig.Name = "cboDesig";
            this.cboDesig.Size = new System.Drawing.Size(121, 21);
            this.cboDesig.TabIndex = 8;
            this.cboDesig.SelectedIndexChanged += new System.EventHandler(this.cboDesig_SelectedIndexChanged_1);
            // 
            // cboDiv
            // 
            this.cboDiv.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboDiv.FormattingEnabled = true;
            this.cboDiv.Location = new System.Drawing.Point(79, 16);
            this.cboDiv.Name = "cboDiv";
            this.cboDiv.Size = new System.Drawing.Size(121, 21);
            this.cboDiv.TabIndex = 7;
            this.cboDiv.SelectedIndexChanged += new System.EventHandler(this.cboDiv_SelectedIndexChanged_1);
            // 
            // rbInd
            // 
            this.rbInd.AutoSize = true;
            this.rbInd.Checked = true;
            this.rbInd.Location = new System.Drawing.Point(7, 14);
            this.rbInd.Name = "rbInd";
            this.rbInd.Size = new System.Drawing.Size(105, 17);
            this.rbInd.TabIndex = 18;
            this.rbInd.TabStop = true;
            this.rbInd.Text = "Individual Report";
            this.rbInd.UseVisualStyleBackColor = true;
            // 
            // lstEmp
            // 
            this.lstEmp.CheckBoxes = true;
            this.lstEmp.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.P_No,
            this.EMPName,
            this.Designation,
            this.Division});
            this.lstEmp.GridLines = true;
            this.lstEmp.Location = new System.Drawing.Point(25, 127);
            this.lstEmp.Name = "lstEmp";
            this.lstEmp.Size = new System.Drawing.Size(444, 209);
            this.lstEmp.TabIndex = 15;
            this.lstEmp.UseCompatibleStateImageBehavior = false;
            this.lstEmp.View = System.Windows.Forms.View.Details;
            // 
            // P_No
            // 
            this.P_No.Text = "P_NO.";
            // 
            // EMPName
            // 
            this.EMPName.Text = "EmpName";
            this.EMPName.Width = 153;
            // 
            // Designation
            // 
            this.Designation.Text = "Designation";
            this.Designation.Width = 95;
            // 
            // Division
            // 
            this.Division.Text = "Division";
            this.Division.Width = 131;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.chk_entdate);
            this.tabPage2.Controls.Add(this.chk_entusr);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.dtp_endate);
            this.tabPage2.Controls.Add(this.cboEnUser);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(492, 361);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Log Report";
            this.tabPage2.UseVisualStyleBackColor = true;
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // chk_entdate
            // 
            this.chk_entdate.AutoSize = true;
            this.chk_entdate.Location = new System.Drawing.Point(71, 82);
            this.chk_entdate.Name = "chk_entdate";
            this.chk_entdate.Size = new System.Drawing.Size(76, 17);
            this.chk_entdate.TabIndex = 36;
            this.chk_entdate.Text = "Entry Date";
            this.chk_entdate.UseVisualStyleBackColor = true;
            // 
            // chk_entusr
            // 
            this.chk_entusr.AutoSize = true;
            this.chk_entusr.Location = new System.Drawing.Point(71, 46);
            this.chk_entusr.Name = "chk_entusr";
            this.chk_entusr.Size = new System.Drawing.Size(75, 17);
            this.chk_entusr.TabIndex = 35;
            this.chk_entusr.Text = "Entry User";
            this.chk_entusr.UseVisualStyleBackColor = true;
            this.chk_entusr.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(123, 14);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(203, 18);
            this.label3.TabIndex = 31;
            this.label3.Text = "SUPREMA LOG REPORT";
            // 
            // dtp_endate
            // 
            this.dtp_endate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_endate.Location = new System.Drawing.Point(177, 82);
            this.dtp_endate.Name = "dtp_endate";
            this.dtp_endate.Size = new System.Drawing.Size(121, 20);
            this.dtp_endate.TabIndex = 29;
            this.dtp_endate.Value = new System.DateTime(2010, 3, 27, 0, 0, 0, 0);
            // 
            // cboEnUser
            // 
            this.cboEnUser.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboEnUser.FormattingEnabled = true;
            this.cboEnUser.Location = new System.Drawing.Point(177, 46);
            this.cboEnUser.Name = "cboEnUser";
            this.cboEnUser.Size = new System.Drawing.Size(121, 21);
            this.cboEnUser.TabIndex = 26;
            this.cboEnUser.SelectedIndexChanged += new System.EventHandler(this.cboEnUser_SelectedIndexChanged_1);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(332, 463);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(94, 28);
            this.button1.TabIndex = 20;
            this.button1.Text = "&Generate";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(432, 463);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(68, 28);
            this.btnClose.TabIndex = 19;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click_1);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pictureBox2.Location = new System.Drawing.Point(0, 447);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(512, 56);
            this.pictureBox2.TabIndex = 18;
            this.pictureBox2.TabStop = false;
            // 
            // frmReports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.ClientSize = new System.Drawing.Size(512, 503);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmReports";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmReports";
            this.Load += new System.EventHandler(this.frmReports_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.SelectionCriteria.ResumeLayout(false);
            this.SelectionCriteria.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtPNO;
        private System.Windows.Forms.GroupBox SelectionCriteria;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cboDesig;
        private System.Windows.Forms.ComboBox cboDiv;
        private System.Windows.Forms.RadioButton rbInd;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dtp_endate;
        private System.Windows.Forms.ComboBox cboEnUser;
        private System.Windows.Forms.CheckBox chk_entdate;
        private System.Windows.Forms.CheckBox chk_entusr;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.ListView lstEmp;
        private System.Windows.Forms.ColumnHeader P_No;
        private System.Windows.Forms.ColumnHeader EMPName;
        private System.Windows.Forms.ColumnHeader Designation;
        private System.Windows.Forms.ColumnHeader Division;
    }
}